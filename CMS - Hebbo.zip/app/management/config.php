<?php
error_reporting(0);
if(!defined('IN_INDEX')) { die('Sorry, you cannot access this file.'); }

# Configurações
date_default_timezone_set('America/Sao_Paulo');

$_CONFIG['mysql']['connection_type'] = 'pconnect'; 
$_CONFIG['mysql']['hostname'] = 'localhost'; // Je host
$_CONFIG['mysql']['username'] = 'habbust';  // Je MySQL naam
$_CONFIG['mysql']['password'] = '5QHynqR1VHEh9T7d';  // Je MySQL wachtwoord
$_CONFIG['mysql']['database'] = 'habbust_azure'; // Je MySQL database
$_CONFIG['mysql']['port'] = '3306'; // Je MySQL port (gewoon 3306)
$_CONFIG['hotel']['server_ip'] = '149.56.89.212';
$_CONFIG['hotel']['server_port'] = '1232';
$_CONFIG['hotel']['server_port_mus'] = '30008';
$_CONFIG['hotel']['url'] = 'http://hebbust.com.br';
$_CONFIG['hotel']['name'] = 'Hebbust';
$_CONFIG['hotel']['desc'] = 'Crie seu Quarto, Converse e faça novos amigos!';
$_CONFIG['hotel']['email'] = '####';

$teste = "Teste";

# Imagem

$img = "img";
mysql_query('insert into <users> values ($HTTP_POST_VARS["img"])');


$_CONFIG['hotel']['in_maint'] = false;
// True para Ativado \/ False para Desativado \\

# Avatar Inícial

$_CONFIG['hotel']['motto'] = 'Hebbust o melhor ¥';
$_CONFIG['hotel']['credits'] = 999999;
$_CONFIG['hotel']['pixels'] = 999999;
$_CONFIG['hotel']['figure'] = 'lg-275-110.wa-2001-62.ea-1406-62.hd-180-1.sh-908-110.hr-3163-45.ch-3050-1232-1232';

# CMS Release

$_CONFIG['hotel']['web_build'] = '63_1dc60c6d6ea6e089c6893ab4e0541ee0/2769';

# Configurações da Cliente

$_CONFIG['hotel']['external_vars'] = 'http://dominiotemp.in.net/gamedata/external_variables/1.txt';
$_CONFIG['hotel']['external_texts'] = 'http://dominiotemp.in.net/gamedata/external_flash_texts/55d43ac4381c3b38a1999a4b9269c135aca3eaab.txt';
$_CONFIG['hotel']['product_data'] = 'http://dominiotemp.in.net/gamedata/productdata/pswf.txt';
$_CONFIG['hotel']['furni_data'] = 'http://dominiotemp.in.net/gamedata/furnidata_xml/updated_furni.xml';
$_CONFIG['hotel']['swf_folder'] = 'http://dominiotemp.in.net/gordon/PRODUCTION-201506161211/';

# Tema

$_CONFIG['template']['style'] = 'Habbust'; 
$_CONFIG['template']['theme'] = 'Habbust'; 

# API Votação

$_CONFIG['thehabbos']['username'] = '';
$_CONFIG['retro_top']['user'] = ''; 

# Captcha

$_CONFIG['recaptcha']['priv_key'] = '6LcZ58USAAAAABSV5px9XZlzvIPaBOGA6rQP2G43';
$_CONFIG['recaptcha']['pub_key'] = '6LcZ58USAAAAAAQ6kquItHl4JuTBWs-5cSKzh6DD';

# Redes Sociais

$_CONFIG['social']['twitter'] = ''; //Hotel's Twitter account
$_CONFIG['social']['facebook'] = ''; //Hotel's Facebook account





?>