<?php

namespace Revolution;
if(!defined('IN_INDEX')) { die('Sorry, you cannot access this file.'); }
interface iJS
{

	public function get();
	
	public function getHK();

	public function setJS();

}
?>


