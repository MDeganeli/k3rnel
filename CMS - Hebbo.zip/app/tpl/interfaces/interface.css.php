<?php

namespace Revolution;
if(!defined('IN_INDEX')) { die('Sorry, you cannot access this file.'); }
interface iCSS
{

	public function get();
	
	public function getHK();

	public function setCSS();

}
?>