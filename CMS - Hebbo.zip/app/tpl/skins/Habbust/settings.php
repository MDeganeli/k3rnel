<?php
$pagename = Ajustes;
$pageid = "3";
include("includes/cabeca.php");
include("includes/menusite.php");
?>
<?php if(isset($template->form->error)) { echo '<div class="alert alert-danger"><center><span class="glyphicon glyphicon-info-sign"></span> '.$template->form->error.'</center></div>'; } ?>
	<body>
		<div class="container">
			
			<div class="col-md-3">
  <div class="panel panel-primary">
    <div class="panel-body">
      <div class="grid_16" style="border-bottom: 2px solid #685D9F;">
        <div class="module-header colorPurple">
          <i class="fa fa-bars fa-lg" style="margin-top: 4px;float:right"></i> Menu
        </div>
      </div>
    </div>
    <div class="list-group news">
      <a href="#1" class="list-group-item" style="border-top-width:0;border-bottom-width: 0;border-left-width: 0;border-right-width: 0;color:#886640;">
        <h4 class="list-group-item-heading">Minha Conta &#187;</h4>
      </a>
      <a href="#2" class="list-group-item" style="border-bottom-width: 0;border-left-width: 0;border-right-width: 0;color:#886640;">
        <h4 class="list-group-item-heading">Mudar Senha &#187;</h4>
      </a>
    </div>
  </div>
</div>
<div class="col-md-9">
  <form method="post" id="Profile">
    <div class="panel panel-primary" id="1">
      <div class="panel-body">
        <div class="grid_16">
          <div class="module-header colorGreen">
            <i class="fa fa-cog fa-lg" style="float: right;"></i> Minha Conta
          </div>
        </div>
        <div id="contentBox" class="activity borderGreen">
          <h4 style="font-size: 20px;">Sua Missão</h4>
        <div class="input-group">
          <span class="input-group-addon" id="motto"><i class="fa fa-comment fa-lg"></i></span>
          <input type="text" class="form-control" name="acc_motto" value="{motto}" placeholder="settings.motto.label" aria-describedby="motto">
        </div>

        <hr style="border: 1px dashed #dddddd;border-top: 0px;">

        <h4 style="font-size: 20px;">Seu Vídeo</h4>
        <small style="font-size: 85%;">Aqui você poderá mostrar a todos seu vídeo favorito... Basta seguir o exemplo abaixo, insira a URL conforme for mostrado...<br>Pegue a sua URL do Vídeo, e pegue apenas o que estiver destacado em <strong style="color:green">VERDE</strong>:<br>http://www.youtube.com/watch?v=<strong style="color:green">NhK8Ehv6aPI</strong></small>
        <div class="input-group">
          <span class="input-group-addon" id="youtube"><i class="fa fa-video-camera fa-lg"></i></span>
          <input type="text" class="form-control" name="acc_youtube" value="{youtube}" placeholder="settings.youtube.label" aria-describedby="youtube">
        </div>

        <hr style="border: 1px dashed #dddddd;border-top: 0px;">
        <input type="submit" name="account" class="btn btn-success" style="float: right;" value="Salvar Modificações" />        </div>
      </div>
    </div></form>
<form method="post" id="profileForm">
    <div class="panel panel-primary" id="2">
      <div class="panel-body">
        <div class="grid_16">
          <div class="module-header colorRed">
            <i class="fa fa-lock fa-lg" style="float: right;"></i> Mudar Senha
          </div>
        </div>
        <div id="contentBox" class="activity borderRed">
          <h4>Antiga Senha</h4>
<div class="input-group">
	<span class="input-group-addon" id="old_password"><span class="glyphicon glyphicon-lock"></span></span>
	<input type="password" class="form-control" name="acc_old_password" placeholder="Antiga Senha" aria-describedby="old_password">
</div>

<hr style="border: 1px dashed #CACACA;border-top: 0px;">

<h4>Nova Senha</h4>
<div class="input-group">
	<span class="input-group-addon" id="new_password"><span class="glyphicon glyphicon-lock"></span></span>
	<input type="password" class="form-control" name="acc_new_password" placeholder="Nova Senha" aria-describedby="new_password">
</div>

<hr style="border: 1px dashed #CACACA;border-top: 0px;">
<br>
<input type="submit" name="account" class="btn btn-success" style="float: right;" value="Salvar Modificações" />        </div>
      </div>
    </div>
  </form>
</div>
<?php  include_once("includes/footer.php"); ?>