	<!-- Icon Shit -->
	<link rel="shortcut icon" type="img/png" href="{url}/content/skin/Gold/assets/img/h.png">

	<!-- Style Shit -->
	<link rel="stylesheet" type="text/css" href="{url}/content/skin/Gold/assets/css/bootstrap.hebbo.css">
	<link rel="stylesheet" type="text/css" href="{url}/content/skin/Gold/assets/css/index.css">
	<link rel="stylesheet" type="text/css" href="{url}/content/skin/Gold/assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="{url}/content/skin/Gold/assets/css/checkbox.css" />

	<!-- JS Shit -->
	<script type="text/javascript" src="//code.jquery.com/jquery-2.1.3.min.js"></script>
	<script type="text/javascript" src="{url}/content/skin/Gold/assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="{url}/content/skin/Gold/assets/js/global.js"></script>
	<script type="text/javascript" src="{url}/content/skin/Gold/assets/js/application.js"></script>

	<!-- FONT Shit -->
	<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>

	<!-- Defined on 'content' System -->