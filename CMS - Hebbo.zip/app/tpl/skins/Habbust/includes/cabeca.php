<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php if ($pageid == 2) {
			echo '<title>{hotelName} Perfil de ';
			echo $username;
			echo '</title>';
		}
		?>
		<title>{hotelName}: <?php echo $pagename; ?></title>
	<!-- Icon Shit -->
	<link rel="shortcut icon" type="img/png" href="{url}/content/skin/Gold/assets/img/h.png">

	<!-- Style Shit -->
	<link rel="stylesheet" type="text/css" href="{url}/content/skin/Gold/assets/css/bootstrap.hebbo.css">
	<link rel="stylesheet" type="text/css" href="{url}/content/skin/Gold/assets/css/entire.css">
	<link rel="stylesheet" type="text/css" href="{url}/content/skin/Gold/assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="{url}/content/skin/Gold/assets/css/checkbox.css" />

	<!-- JS Shit -->
	<script type="text/javascript" src="//code.jquery.com/jquery-2.1.3.min.js"></script>
	<script type="text/javascript" src="{url}/content/skin/Gold/assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="{url}/content/skin/Gold/assets/js/global.js"></script>
	<script type="text/javascript" src="{url}/content/skin/Gold/assets/js/application.js"></script>

	<!-- FONT Shit -->
	<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>

	<!-- Defined on 'content' System -->
		<script src="http://hebbohotel.in/content/skin/Umbar/assets/js/lightweightmepage.js?3"></script>
<script src="http://hebbohotel.in/content/skin/Umbar/assets/js/radio.js?25"></script>
	</head>