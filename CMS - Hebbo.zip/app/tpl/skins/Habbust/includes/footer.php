<div class="clr"></div>
<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-md-12 text-center">
				<p><i class="fa fa-registered"></i><strong> HearCMS 4S</strong> foi <i style="color:#BA4F98;" class="fa fa-code"></i> com <i style="color:red;" class="fa fa-heart"></i> por <strong><a href="http://raphaleao.com" style="color:#886640;" target="_blank">Helpi</a></strong>, <strong>Andrew</strong> & <strong>Equipe Hebbust</strong>.
					<br>
					Tema Atual: <strong>Hebbust</strong></p>
				</div>
			</div>
		</div>
		</footer></body>