<nav class="navbar navbar-default navbar-static-top">
	<div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only" style="margin-top: -1px;position: absolute;">Menu</span>
        <span class="icon-bar" style="background-color: #fff;margin-right: 39px;"></span>
        <span class="icon-bar" style="background-color: #fff;margin-right: 39px;"></span>
        <span class="icon-bar" style="background-color: #fff;margin-right: 39px;"></span>
      </button>
      <a class="navbar-brand" style="padding: 0;margin-left: 0;" href="http://habbust.in"><div id="logoh"></div></a>
    </div>
    <div id="navbar" class="navbar-collapse collapse">
  <ul class="nav navbar-nav" style="float: none;">
    <form method="post">
      <div class="navbar-form">
        <div class="input-group" style="margin-top: 2px;">
          <span class="input-group-addon group-custom" id="basic-addon1"><span class="glyphicon glyphicon-user"></span></span>
          <input type="text" class="form-control form-custom" placeholder="Usuário" value="" name="log_username" aria-describedby="basic-addon1" required="">
        </div>

        <div class="input-group" style="margin-top: 2px;">
          <span class="input-group-addon group-custom" id="basic-addon1"><span class="glyphicon glyphicon-asterisk"></span></span>
          <input type="password" class="form-control form-custom" placeholder="Sua Senha" value="" name="log_password" aria-describedby="basic-addon1" required="">
        </div>

        <div class="input-group" style="margin-top: 2px;">
          <input type="submit" name="login" class="btn btn-success" value="Conectar!">
        </div>
        <div class="input-group" style="margin-top: 10px;">
          <input type="checkbox" id="remember" name="remember" class="custom-checkbox">
          <label for="remember">
            <div class="stylable-checkbox">
              <span class="checkbox-icon">✔</span>
              <span class="checkbox-linefix">&nbsp;</span>
            </div>
            Lembrar-me
          </label>
        </div>
      </div>
    </form>
  </ul>
</div>
</div>
</nav>