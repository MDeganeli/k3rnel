<nav class="navbar navbar-default navbar-static-top">
	<div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only" style="margin-top: -1px;position: absolute;">Menu</span>
        <span class="icon-bar" style="background-color: #fff;margin-right: 39px;"></span>
        <span class="icon-bar" style="background-color: #fff;margin-right: 39px;"></span>
        <span class="icon-bar" style="background-color: #fff;margin-right: 39px;"></span>
      </button>
      <a class="navbar-brand" style="padding: 0;margin-left: 0;" href="{url}"><div id="logoh"></div></a>
    </div>
        <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav" style="float: none;">
       <div class="avatar lazy" data-original="http://avatar-retro.com/habbo-imaging/avatarimage?figure={figure}&size=b&direction=3&head_direction=3&crr=3&gesture=sml&frame=3&action=wav&img_format=png" style="display: block; background-image: url('http://avatar-retro.com/habbo-imaging/avatarimage?figure={figure}&size=b&direction=3&head_direction=3&crr=3&gesture=sml&frame=3&action=wav&img_format=png');background-repeat: no-repeat;">            	
       </div>
       <h3 style="text-transform: none;">{username}</h3>
       <div class="menu" style="text-transform: none;">
        <?php if ($pageid == 1) { // PAGINA INICIAL
			  echo '        <div class="botao botao-active">';
		  }
		  else {
			  echo '<div class="botao">';
		  }
		  ?>
		  <a href="{url}/me">
          <span class="glyphicon glyphicon-home" aria-hidden="false"></span> Início
        </div>
        </a>
		  <?php if ($pageid == 2) { //PAGINA PROFILE
			  echo '        <div class="botao botao-active">';
		  }
		  else {
			  echo '<div class="botao">';
		  }
		  ?>
		  <a href="{url}/profile/{username}">
          <span class="glyphicon glyphicon-user" aria-hidden="false"></span> Minha Página
          </div>
        </a>
		<?php if ($pageid == 3) { //PAGINA SETTINGS
			  echo '        <div class="botao botao-active">';
		  }
		  else {
			  echo '<div class="botao">';
		  }
		  ?>
                        <a href="{url}/settings">
            <span class="glyphicon glyphicon-cog" aria-hidden="false"></span> Ajustes
          </div>
        </a>
           <?php if ($pageid == 4) { //PAGINA COMUNIDADE
			  echo '        <div class="botao botao-active">';
		  }
		  else {
			  echo '<div class="botao">';
		  }
		  ?>
        <li role="presentation" class="dropdown" style="list-style: none;">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
           <i class="fa fa-comments-o"></i>  Comunidade <span class="caret"></span>
         </a>
         <ul class="dropdown-menu">
                      <li><a href="{url}/news"><i class="fa fa-newspaper-o"></i> Notícias</a></li>
           <li><a href="{url}/staff"><i class="fa fa-star"></i> Nossa Equipe</a></li>
		   <li><a href="{url}/fama"><i class="fa fa-diamond"></i> Hall da Fama</a></li>
         </ul>
       </li>
     </div>
          <a href="{url}/logout">
      <div class="botao-exit">
        <span class="glyphicon glyphicon-off" aria-hidden="false"></span> Sair do Hebbust
      </div>
    </a>
  </div>
</ul>
</div>
</div>
</nav>