<!DOCTYPE html>
<?php header("Content-type: text/html; charset=utf-8"); ?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="https://www.facebook.com/2008/fbml">
  <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="Helpi&Luck">
	<title>{hotelName} - Celular</title>

<?php  include_once("includes/styles.php"); ?>
</head>
	<body>
<?php  include_once("includes/menu.php"); ?>
		<div class="container">
			
  <div class="col-md-3" style="margin-top:2px;width:1150px;">
    	<div class="panel panel-primary">
    		<div style="background-color:orange;"class="panel-heading">
          		<h3 class="panel-title"><i class="fa fa-question" style="float:right"></i>Saiba mais...</h3>
      		</div>
  <div class="panel-body">
  <h3><span class="label label-default">Aprenda já!</span></h3>
  </br>
    <p>Ol&aacute; {username}, voc&ecirc; tem celular e quer jogar o {hotelName}?</p>
    <p>Aqui vai um tutorial:</p>
    </br>
    <span class="label label-success">Android e iOS</span>
    </br>
    </br>
    <p>1- Voc&ecirc; vai baixar um aplicativo chamado: <strong>Puffin Web Browser</strong></p>
    <p>2- Pronto s&oacute; entrar no Habbust e jogar!</p>
    <a href="https://play.google.com/store/apps/details?id=com.cloudmosa.puffinFree&hl=pt-br"><button type="button" class="btn btn-default navbar-btn">Baixar</button></a>
  </div>
  </div>
  </div>


<?php  include_once("includes/footer.php"); ?>
		</div>
	</body>
</html>