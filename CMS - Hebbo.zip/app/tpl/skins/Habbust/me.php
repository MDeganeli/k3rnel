<?php
$pagename = Principal;
$pageid = "1";
include("includes/cabeca.php");
include("includes/menusite.php");
?>
<body>
		<div class="container">
<div class="col-xs-12 col-md-7" style="margin-right: 15px;">
	<div class="row">
		<div class="jumbotron jumbo front">				
			<div class="col-xs-2 col-md-2">
				<div style="margin-top: 19px;margin-left: 60px;height: 106px;width: 65px;background-image: url('http://avatar-retro.com/habbo-imaging/avatarimage?figure={figure}&size=b&direction=2&head_direction=3&gesture=sml&frame=3&action=sit&img_format=png');"></div>
			</div>
			<div class="col-xs-9 col-sm-6" style="float:right;">
				<a href="/client" target="_blank" class="btn btn-success" style="font-size: 15px;text-transform: none;width:100%;border-bottom-left-radius: 0px;border-bottom-right-radius: 0px;"><i class="fa fa-sign-in"></i>
					Jogar Agora!
				</a>
				<span class="btn btn-warning" style="cursor: default;font-size: 15px;text-transform: none;width:100%;border-top-left-radius: 0px;border-top-right-radius: 0px;"><i class="fa fa-users"></i>
				{online} Usuário(s) Online!
				</span>
			</div>
		</div>			
	</div>

	<div class="row">
		    <div class="list-group news">
			
<?php
$to5 = mysql_query("SELECT * FROM cms_news ORDER BY ID DESC LIMIT 3") or die(mysql_error());
?>

<?php $i = 0; while($newsobject = mysql_fetch_assoc($to5)){ $i++; ?>
			
    <div class="list-group news">
            <div style="background:url(<?php echo $newsobject['image']; ?>)<?php if($i != '1'){ ?>; display: none<?php } ?>" class="active habbo-container newsbox">
      <div class="news-item" style="background: rgba(0,0,0,0.6);">
        <div class="news-header"><?php echo $newsobject['title']; ?></div>
        <div class="news-teaser"><?php echo $newsobject['shortstory']; ?></div>
        <a class="readmore" href="{url}/index.php?url=news&id=<?php echo $newsobject['id']; ?>">Leia Mais</a>
      </div>
    </div>
    </div>

<?php }?>
			
			</div>
	<br><br><br><br><br><br><br><br><br><br><br>
	
	<div class="col-sm-4" style="margin-top: 30px;">
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-body">
				<div class="grid_16" style="border-bottom: 2px solid #A27C1D;">
					<div class="module-header colorPink">
						<img src="{url}/content/skin/Gold/assets/img/coins.png" style="margin-top:5px;float:right"> Top Moedas
					</div>
				</div>
			</div>
<?php
$e = mysql_query("SELECT username,look,credits,id FROM users WHERE rank < 5 ORDER BY credits DESC LIMIT 5");
while($f = mysql_fetch_array($e)){
?>			
			<div class="list-group">
<a class="list-group-item" style="text-decoration: none;" href="{url}/profile/<?php echo $f['username']; ?>">
					<div class="media">
						<div class="media-left">
							<div style="background-image: url(http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $f['look']; ?>&amp;size=m&amp;direction=2&amp;head_direction=2&amp;gesture=sml&img_format=png); background-position: -2px -17px; width:50px; height:50px;">
							</div>
						</div>
						<div class="media-body">
								<b><?php echo $f['username']; ?></b> &nbsp;
								<br><span class="currency credits"><?php echo $f['credits']; ?></span>
							</div>
						</div>
					</a>
<?php } ?>
			</div>
		</div>
	</div>
</div>
</div></div></div></div>
<div class="col-sm-4" style="margin-top: 30px;">
	<div class="panel panel-primary">
		<div class="panel-body">
			<div class="grid_16" style="border-bottom: 2px solid #B275B3;">
				<div class="module-header colorBeige">
					<img src="{url}/content/skin/Gold/assets/img/duckets.png" style="margin-top: 4px;float:right"> Top Duckets
				</div>
			</div>
		</div>
<?php
$e = mysql_query("SELECT username,look,activity_points,id FROM users WHERE rank < 5 ORDER BY activity_points DESC LIMIT 5");
while($f = mysql_fetch_array($e)){
?>		
		<div class="list-group">
<a class="list-group-item" style="text-decoration: none;" href="{url}/profile/<?php echo $f['username']; ?>">
				<div class="media">
					<div class="media-left">
						<div style="background-image: url(http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $f['look']; ?>&amp;size=m&amp;direction=2&amp;head_direction=2&amp;gesture=sml&img_format=png); background-position: -2px -17px; width:50px; height:50px;">
						</div>
					</div>
					<div class="media-body">
								<b><?php echo $f['username']; ?></b> &nbsp;
								<br><span class="currency activity_points"><?php echo $f['activity_points']; ?></span>
							</div>
						</div>
					</a>
<?php } ?>
			</div>
	</div>
</div>
</div></div></div></div>
<div class="col-sm-4" style="margin-top: 30px;">
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-body">
				<div class="grid_16" style="border-bottom: 2px solid #DB0000;">
					<div class="module-header colorDiamond">
						<img src="{url}/content/skin/Gold/assets/img/pipocas.gif" style="margin-top: 4px;float:right"> Top Pipocas
					</div>
				</div></div>
<?php
$e = mysql_query("SELECT username,look,vip_points,id FROM users WHERE rank < 5 ORDER BY vip_points DESC LIMIT 5");
while($f = mysql_fetch_array($e)){
?>			
			<div class="list-group">
<a class="list-group-item" style="text-decoration: none;" href="{url}/profile/<?php echo $f['username']; ?>">
					<div class="media">
						<div class="media-left">
							<div style="background-image: url(http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $f['look']; ?>&amp;size=m&amp;direction=2&amp;head_direction=2&amp;gesture=sml&img_format=png); background-position: -2px -17px; width:50px; height:50px;">
							</div>
						</div>
						<div class="media-body">
								<b><?php echo $f['username']; ?></b> &nbsp;
								<br><span class="currency pipocas"><?php echo $f['vip_points']; ?></span>
							</div>
						</div>
					</a>
<?php } ?>
			</div>
		</div>
	</div>
</div></div>
</div>
</div>
</div></div></div>
<div class="col-xs-12 col-sm-4" style="margin-right: 15px;">
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-body">
				<div class="grid_16">
					<div class="module-header colorGreen">
						<i class="fa fa-music fa-lg" style="float: right;"></i> Rádio Hebbust
					</div>
				</div>
</div>
				<div id="contentBox" class="activity borderGreen">
					<div class="radio" id="radiostart">
						<span class="glyphicon glyphicon-play active" id="radio-play" data-toggle="tooltip" data-placement="right" title="Iniciar"></span>
						<span class="glyphicon glyphicon-pause" id="radio-pause" data-toggle="tooltip" data-placement="right" title="Pausar"></span>
						<span class="glyphicon glyphicon-volume-down" id="volume-down" data-toggle="tooltip" data-placement="right" title="Baixar Volume"></span>
						<span class="glyphicon glyphicon-volume-up" id="volume-up" data-toggle="tooltip" data-placement="right" title="Aumentar Volume"></span>
						<span class="glyphicon glyphicon-volume-off" id="volume-off" data-toggle="tooltip" data-placement="right" title="Mutar"></span>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="col-xs-12 col-sm-4">
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-body">
				<div class="grid_16">
					<div class="module-header colorBlue">
						<i class="fa fa-facebook fa-lg" style="float: right;"></i> Siga-nos
					</div>
				</div>
				<div id="contentBox" class="activity borderBlue">
					<div class="fb-page" data-href="https://www.facebook.com/HebbustOficial/" data-tabs="timeline" data-height="440" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/HebbustOficial/"><a href="https://www.facebook.com/HebbustOficial/">Hebbo</a></blockquote></div></div><div id="fb-root"></div>
				</div>
			</div>
		</div>
	</div>			
</div>
<?php  include_once("includes/footer.php"); ?>