<?php 
		// Include styles
		include "includes/style.php"; 
	?>
<body>
	<?php 
		// Include Header
		include "includes/header.php"; 
	?>
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php 
						// Include Navigator
						include "includes/navigator.php";
					?>
				</div>
			
				<div class="span9">
					<div class="alert alert-error">
						<button type="button" class="close" data-dismiss="alert">×</button>
						Dúvidas? Algum erro? Qualquer tipo de problemas com os recursos atuais, por favor, informar à <b>Killua</b> ou <b>OldFl4sh</b>
					</div>
				
					<div class="content">
						<div class="btn-controls">
							<div class="btn-box-row row-fluid">
								<a href="#" class="btn-box big span4"><i class=" icon-group"></i><b>{online}</b>
									<p class="text-muted">
										Usuários online</p>
								</a>
								
								<a href="#" class="btn-box big span4"><i class="icon-user"></i><b>
									<?php 
										$query = mysql_query("SELECT COUNT(*) AS stats1 FROM users") or die(mysql_error()); 
										$data = mysql_fetch_assoc($query); 
										echo number_format($data['stats1']); 
									?>	
								</b>
									<p class="text-muted">
										Usuários registrados</p>
								</a><a href="#" class="btn-box big span4"><i class="icon-ban-circle"></i><b><?php echo number_format(mysql_num_rows(mysql_query("SELECT NULL FROM users_bans"))); ?></b>
									<p class="text-muted">
										Usuários banidos</p>
								</a>
							</div>
						</div>
					</div>
				</div>
							
				<div class="span5">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Últimos banimentos</h3>
							</div>
							<div class="module-body">
								<table class="table table-striped">
									<thead>
										<tr>
											<th>ID</th>
											<th>Usuário/IP</th>
											<th>Razão</th>
											<th>Tipo</th>
											<th>Banido por</th>
										</tr>
									</thead>
									<tbody>										
									<?php
										$getBans = mysql_query("SELECT * FROM users_bans ORDER BY id DESC LIMIT 10")or die(mysql_error());
										while ($bans = mysql_fetch_assoc($getBans)){
										echo'
											<tr>
												<td>'. $bans['id'] .'</td>
												<td>'. $bans['value'] .'</td>
												<td>'. $bans['reason'] .'</td>
												<td>'. $bans['bantype'] .'</td>
												<td>'. $bans['added_by'] .'</td>
											</tr>';
										}
									?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
				
				<div class="span4">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Meu perfil</h3>
							</div>
							<div class="module-body">
								<table class="table table-striped table-bordered table-condensed" border="0" cellspacing="0" cellpadding="0">
									<tr>
										<td width="35%" rowspan="4" valign="top">
											<center><img src="http://www.habbo.nl/habbo-imaging/avatarimage?figure={figure}&direction=3&head_direction=3&gesture=sml&size=m"></center>
										</td>
										<td width="65%" valign="top"><b>{username}</b><br /><small>{motto}</small></td>
									</tr>
									
									<tr>
										<td width="65%" valign="top">{coins} Credits</td>
									</tr>
									
									<tr>
										<td width="65%" valign="top">{activitypoints} Duckets</td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<?php include "includes/footer.php"; ?>
	<!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>
</body>