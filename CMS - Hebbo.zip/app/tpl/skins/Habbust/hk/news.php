<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

    <title>{hk_name} - DashBoard</title>

 <!-- Bootstrap core CSS -->
    <link href="{url}/ase/bootstrap/css/bootstrap.css" rel="stylesheet">

	 <!-- Script Box Editor -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="{url}/app/tpl/skins/{skin}/hk/scripts/ckeditor/ckeditor.js"></script>
		<script src="{url}/app/tpl/skins/{skin}/hk/scripts/ckeditor/adapters/jquery.js"></script

  </head>

  <body>

    <!-- Static navbar -->
    <div class="navbar navbar-default navbar-static-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php?url=dash">{hotelName}</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li>
			<a href="index.php?url=dash">Início</a></li>
			<?php if($_SESSION['user']['rank'] > 8){ ?><li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Notícias<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="index.php?url=news">Criar uma notícia</a></li>
                <li><a href="index.php?url=delnews">Editar notícia</a></li>
              </ul>
            </li><?php } ?>          
<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Usuários<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="index.php?url=edit">Editar Usuário</a></li>
				<li><a href="index.php?url=hall">Dar ponto no Hall</a></li>
              </ul>
            </li>
          <ul class="nav navbar-nav navbar-right" style=" margin-right: 0px; ">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle dker" data-toggle="dropdown">
            			{username}<b class="caret">
            </b>
          </a>
		  		  <ul class="dropdown-menu">
            <li>
              <a href="{url}/client">
                Entrar no {hotelName}              </a>
            </li>
         <li>
              <a href="{url}">
                Voltar ao {hotelName}             </a>
          </ul>
		          </li>
      </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>


    <div class="container">         
					<div class="content">
						<div class="module">
							<div class="module-head">
							
								<h3>Adicionar nova notícia</h3>
							</div>
							<div class="module-body">

								<?php
								if($_SESSION['user']['rank'] >= 8){

								function secureStr($str) {
									return mysql_real_escape_string(stripslashes(htmlspecialchars($str)));
								}
								if(isset($_POST['news_create'])) {
									$title = secureStr($_POST['title']);
									$shortstory = secureStr($_POST['shortstory']);
									$longstory = secureStr($_POST['longstory']);
									$lookdocriador = secureStr($_POST['look']);
									$topstory = secureStr(mysql_real_escape_string($_POST['topstory']));
									
									
									
									if(empty($title)){
										echo '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">×</button><strong>Error:</strong> You have not entered a Title.</div>';
									}
									
									else if(empty($shortstory)){
										echo '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">×</button><strong>Error:</strong> You have not entered a Short Story.</div>';
									}
									
									else if(empty($longstory)){
										echo '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">×</button><strong>Error:</strong> You havent entered a Long Story.</div>';
									}
									
									else{
										$q = "INSERT INTO cms_news (title, shortstory, longstory, published, image, author,look) VALUES('{$title}','{$shortstory}','" . htmlspecialchars_decode($longstory) . "'," . time() . ",'{$topstory}','". $_SESSION['user']['username'] ."','". $lookdocriador."')";
										$q_nupdate = "INSERT INTO hk_logs (type, time, who_done) VALUES('News Article(" . $_POST['title'] .")','". time() ."','{$_SESSION['user']['username']}')";

										mysql_query($q) or die(mysql_error());
										mysql_query ($q_nupdate);
										header("Location:index.php?url=dash ",5);
										echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">×</button><strong>Well done!</strong> News Article created.</div>';
									}
								}
								?>


									<form method="post" class="form-horizontal row-fluid">
										<div class="control-group">
										<label class="control-label" for="basicinput">Título</label>
										<div class="controls">
											<input type="text" name="title" value="<?php echo $_POST['title']?>" placeholder="Título" class="span8">
										</div>
										</div>
										
										<div class="control-group">
											<label class="control-label" for="basicinput">Descrição</label>
											<div class="controls">
												<input type="text" name="shortstory" value="<?php echo $_POST['shortstory']?>" placeholder="Descrição" class="span8">
											</div>
										</div>
										
										<div class="control-group">
											<textarea cols="80" id="editor1" rows="10" name="longstory" class="span8"></textarea>
											<script>
												// THIS IS REQUIRED JAVASCRIPT FOR THE NEWS EDITOR
												CKEDITOR.replace( 'editor1' );
											</script>
										</div>
										
										<div class="control-group">
											<label class="control-label" for="basicinput">Autor</label>
											<div class="controls">
												<input type="text" class="span8" value="<?php echo $_SESSION['user']['username']; ?>" disabled>
											
											
													<?php
														$username = $_SESSION['user']['username'];
														$pegaLok = mysql_query("SELECT look FROM users WHERE username = '".$username."'");
														while($dados = mysql_fetch_array($pegaLok)){
															$look = $dados['look']; /*cria uma noticia */
														}
													?>
											<label class="control-label" for="basicinput">Não mexer aqui</label>	
											<input type = "text" name = "look"  value='<?php echo $look; ?>' >
											</div>
										</div>
									
										<div class="control-group">
											<label class="control-label" for="basicinput">Imagem de Capa:</label>
												<div class="controls">
													<input type = "text" name = "topstory" value = "<?php echo $_POST['topstory']?>" placeholder = "Link Aqui"></br>
													<p><a target="_blank" href="http://cammex.net/hotel/promo.php">Clique Aqui</a> para obter o link das imagens</p>
												</div>
										</div>
										
										<div class="control-group">	
											<div class="controls">	
												
												<input type="submit" class="btn btn-small btn-primary" name="news_create">
											</div>
										</div>
									</form>
									<?php }
									else{
										die('Go away please.');
									}
									?>
								
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>


<?php include ("includes/footer.php"); ?>  

    <!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>

  </body>
</html>