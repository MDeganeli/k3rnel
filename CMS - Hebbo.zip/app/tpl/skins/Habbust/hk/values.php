<?php
	if($_SESSION["in_hk"] == false){
		header("Location: /me");
			exit();
	}

	$getUseRank4Page = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
	$perms = mysql_fetch_assoc(mysql_query("SELECT * FROM housekeeping_perms WHERE `perm` = 'perm_filter'"));
	if ($perms['rank'] > $getUseRank4Page['rank']){
		header("Location: index.php?url=main");
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>{hotelName} ASE - Rare Values</title>
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/css/theme.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="{url}/app/tpl/skins/{skin}/hk/scripts/ckeditor/ckeditor.js"></script>
		<script src="{url}/app/tpl/skins/{skin}/hk/scripts/ckeditor/adapters/jquery.js"></script>
</head>

<body>
	<?php include "includes/header.php"; ?>
		
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php include "includes/navigator.php"; ?>
				</div>
							
				<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Add Rare Value</h3>
							</div>
							
							<div class="module-body">
							
							<?php
							if($_SESSION['user']['rank'] >= 6){

							function secureStr($str) {
								return mysql_real_escape_string(stripslashes(htmlspecialchars($str)));
							}
							if(isset($_POST['rare_submit'])) {
								$rarename = secureStr($_POST['rare']);
								$cost = secureStr($_POST['cost']);
								
								if(empty($cost)){
									echo '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">×</button><strong>Error:</strong> You have not entered an amount of coins!.</div>';
								}
								
								else{
									$q = "INSERT INTO cms_rarevalues (rare_name, date_added, cost, added_by) VALUES('{$rarename}'," . time() . ",'{$cost}','". $_SESSION['user']['username'] ."')";

									mysql_query($q) or die(mysql_error());
									echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">×</button><strong>Well done!</strong> Rare Value Added</div>';
								}
							}
							else if($_POST['rare_view']){ ?>
								<p><center><img src="{url}/ase/value_images/<?php echo $_POST['rare']; ?>"></center></p>
							<?php } ?>
							
								<form method="post" class="form-horizontal row-fluid">
									<div class="control-group">
										<label class="control-label" for="basicinput">Rare Name</label>&nbsp;
											<select name="rare" style="font-size: 14px;">
												<?php 
													if ($handle = opendir('value_images/'))
														{	
														while (false !== ($file = readdir($handle)))
															{
																if ($file == '.' || $file == '..')
																{
																	continue;
																}		
																echo '<option value="' . $file . '"';
																if (isset($_POST['rare']) && $_POST['rare'] == $file)
																	{
																		echo ' selected';
																	}
																	echo '><li>' . $file . '</li></option>';
														}
													}
												?>
											</select>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="basicinput">Cost</label>
										<div class="controls">
											<input type="text" name="cost" placeholder="10000" class="span8">
										</div>
									</div>
								
									<div class="control-group">
										<label class="control-label" for="basicinput">Author</label>
										<div class="controls">
											<input type="text" class="span8" value="<?php echo $_SESSION['user']['username']; ?>" disabled>
										</div>
									</div>
									
									<div class="control-group">	
										<div class="controls">	
											<input type="submit" class="btn btn-small btn-primary" name="rare_view" value="View Rare">
											<input type="submit" class="btn btn-small btn-primary" name="rare_submit">
										</div>
									</div>
								</form>
								<?php }
								else{
									die('Go away please.');
								}
								?>
							</div>
						</div>
						
						<div class="module">
							<div class="module-head">
								<h3>Current Values</h3>
							</div>
							<div class="module-body">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped  display dataTable" width="100%" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info" style="width: 100%;">
									<thead>
										<tr>
											<th>Rare Name</th>
											<th>Current Cost</th>
											<th>Date Added</th>
											<th>Added By</th>
										</tr>
									</thead>
									<tbody>										
									<?php
										$getValues = mysql_query("SELECT * FROM cms_rarevalues ORDER BY id ASC")or die(mysql_error());
										while ($values = mysql_fetch_assoc($getValues)){
											
										$removeUnderscore = str_replace("_", " ", $values['rare_name']); // Remove any underscores and replace with a space
										$removeGif = str_replace(".gif", " ", $removeUnderscore); // Remove .gif from end of file name
										$rarename = ucwords(strtolower($removeGif)); // Make first letter of variable a capital. e.g "nelly gold" to "Nelly Gold"
											
										echo'
											<tr>
												<td>'. $rarename.'</td>
												<td>'. $values['cost'] .'</td>
												<td>'. $values['date_added'] .'</td>
												<td>'. $values['added_by'] .'</td>
												<td><a href="/ase/index.php?url=editvalue&id='. $values['id'] .'">Edit</a></td>
											</tr>';
										}
									?>
									</tbody>
								</table>
							</div>
						</div>	
					</div>
				</div>
				
			</div>
		</div>
	</div>

	<?php include "includes/footer.php"; ?>
	
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/common.js" type="text/javascript"></script>
</body>