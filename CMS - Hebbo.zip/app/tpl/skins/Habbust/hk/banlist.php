<?php 
		// Include styles
		include "includes/style.php"; 
	?>
<body>
	<?php 
		// Include Header
		include "includes/header.php"; 
	?>
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php 
						// Include Navigator
						include "includes/navigator.php";
					?>
				</div>
     <div class="span9">
          <div class="content">
						<div class="module">
							<div class="module-head">
             <h3>Jogadores banidos</h3>
							</div>
							<div class="module-body">
                  <table width="100%">
        <tr><td><b>Usuário banido:</b></td><td><b>Razão</b></td><td><b>Banido por:</b></td><td><b>ID</b></td><td><b>Expira:</b></td></tr>
        <?php                                // Make a MySQL Connection
                                        $query = "SELECT * FROM users_bans ORDER by id DESC"; 
             
                                        $result = mysql_query($query) or die(mysql_error());




                                        while($row = mysql_fetch_array($result))
                                        {
                                        echo("<tr>");
                                        echo("<td>" . $row['value'] . "</td>");
                                        echo("<td>" . $row['reason'] . "</a></td>");
                                        echo("<td>" . $row['added_by'] . "</td>");
                                        echo("<td>" . $row['id'] . "</td>");
                                        
                                        
                                        // Now we convert the Unix timestamp to a humanley readable time
                                        $timestamp = $row['expire'];
                                        $date = date("D-m-Y H:i:s", $timestamp);
                                        
                                        echo("<td>$date</td></tr>");
                                        }
                                        ?>

                                </table>
		                    </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php include ("includes/footer.php"); ?>  
    <!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>

  </body>
</html>
