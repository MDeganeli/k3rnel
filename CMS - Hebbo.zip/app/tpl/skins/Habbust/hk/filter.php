<?php
	if($_SESSION["in_hk"] == false){
		header("Location: /me");
			exit();
	}

	$getUseRank4Page = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
	$perms = mysql_fetch_assoc(mysql_query("SELECT * FROM housekeeping_perms WHERE `perm` = 'perm_filter'"));
	if ($perms['rank'] > $getUseRank4Page['rank']){
		header("Location: index.php?url=main");
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>{hotelName} ASE - Filter</title>
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/css/theme.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
</head>

<body>
	<?php 
		// Include Header
		include "includes/header.php"; 
	?>
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php 
						// Include Navigator
						include "includes/navigator.php";
					?>
				</div>
				
				<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Add Word to Filter</h3>
							</div>
							<div class="module-body">
							
								<?php
									if($_SESSION['user']['rank'] >= 6)
									{
										if($_POST['filter']){
											
											$getFilter = mysql_query("SELECT * FROM `wordfilter` WHERE `word` = '".$_POST['word']."'");
											$filter = mysql_fetch_array($getFilter);
											
											if ($_POST['word'] == $filter['word'])
											{
												echo '					
												<div class="alert alert-error">
													<button type="button" class="close" data-dismiss="alert">×</button>
													<strong>Error</strong> The word <strong>'.$_POST['word'].'</strong> is already a blocked word, please check and try again.
												</div>';  						
											}
											else
											{
												mysql_query("INSERT INTO `wordfilter` (word) VALUES('".$_POST['word']."')") or die(mysql_error()); 
												MUS(update_filter,"");
												echo '					
												<div class="alert alert-sucess">
													<button type="button" class="close" data-dismiss="alert">×</button>
													<strong>Well Done!</strong> The word <strong>'.$_POST['word'].'</strong> is now a blocked word.
												</div>'; 						
											}
											
										}
									}
								?>
							
								<form class="form-horizontal row-fluid" method="post">
									<div class="control-group">
										<label class="control-label" for="basicinput">Word</label>
										<div class="controls">
											<input type="text" id="basicinput" name="word" placeholder="Word to be filtered" class="span8">
										</div>	
									</div>
									
									<div class="control-group">
										<div class="controls">
											<input type="submit" name="filter" class="btn btn-primary">
										</div>
									</div>
								</form>
							</div>
						</div>
						
						<div class="module">
							<div class="module-head">
								<h3>Filtered Words</h3>
							</div>
							<div class="module-body">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped  display dataTable" width="100%" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info" style="width: 100%;">
									<thead>
										<tr>
											<th>Word</th>
											<th>Replacement</th>
										</tr>
									</thead>
									<tbody>										
									<?php
										$getBans = mysql_query("SELECT * FROM wordfilter ORDER BY word ASC")or die(mysql_error());
										while ($bans = mysql_fetch_assoc($getBans)){
										echo'
													<tr>
														<td>'. $bans['word'] .'</td>
														<td>'. $bans['replacement'] .'</td>
													</tr>';
										}
									?>
									</tbody>
								</table>
							</div>
						</div>	
						
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<?php include "includes/footer.php"; ?>
		
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/common.js" type="text/javascript"></script>
</body>