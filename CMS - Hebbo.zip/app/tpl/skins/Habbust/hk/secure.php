<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Lockscreen : Locked</title>

		<meta charset="UTF-8">
		<meta name="description" content="Win8 Styled lockscreen">
		<meta name="keywords" content="Lockscreen,Windows8">
		<meta name="author" content="Explorer @Retronet">

		<link rel="stylesheet" type="text/css" href="../app/tpl/skins/{skin}/hk/base/fonts.css"/>
		<link rel="stylesheet" type="text/css" href="../app/tpl/skins/{skin}/hk/base/main.css"/>
		<link href="../app/tpl/skins/{skin}/hk/base/img/favicon.ico" rel="icon" type="image/x-icon" />
		<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Tangerine" type="text/css" />
		
		<style type=text/css> 
        h3 {
            font: 14px "Comic Sans MS", cursive, sans-serif;
            color: #FFF;
            font-weight: 200;
        }
    </style>

        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="//code.jquery.com/jquery-1.10.2.js"></script>
        <script src="//code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
	</head>

	<body>

		<div class="globContainer">
			<div class="lock">
				<div class="left userAvatar">
					<img src="http://www.habbo.nl/habbo-imaging/avatarimage?figure={figure}&direction=2&action=wav&head_direction=3&gesture=sml&size=big"/>
				</div>

				<div class="left">
					<form action="#" method="POST" name="lockForm">
						<h3>Pin {hotelName}</h3>
						<input type="password" id="code" name="code" placeholder="Admin code" class="form-control" <?php if(isset($_POST['unlock'])) echo 'value="'. $_POST['code'] .'"'; ?> /> <br />
						<input type="submit" name="unlock" value="Enter manager" class="unlock"/>
					</form>
				</div>
			</div>

			<div class="messages">
				<div class="error" id="error" style="display: none;"></div>
				<div class="success" id="success" style="display: none;"></div>
			</div>
		</div>

		<?php
			// Starts the sessions, if you get an error that says 'Sessions already started', 
			// then you just need to delete this rule.
			session_start();

			if(isset($_POST['unlock'])) {

				if(!empty($_POST['code'])) {

					// The 'PutYourSecretPassHere' will be the unlock key - don't change anything 
					// else unless you know what you're doing!!
					$code = sha1('hbk15', md5(date('d-m-Y')));

					if(sha1($_POST['code'], md5(date('d-m-Y'))) == $code) {

						$user  = $_SESSION['user']['username'];
						$check = mysql_fetch_assoc(mysql_query('SELECT * FROM users WHERE username = "'. $user .'"'));

						// Users with rank 4 or higher can access the housekeeping, this is
						// the same as in your standard /app/class.users.php on line 270, 
						// you can edit it if you want to
						if($check['rank'] >= 4) { 

							$_SESSION['control_check'] = true;
							
							$success = "<a href='dash'><b>Klik hier</b> om verder te gaan!</a>";
							echo '<script type="text/javascript">
									 $("#code").attr("disabled", "disabled");
									 $("#code").addClass("checked");
									 $("#success").html("'.$success.'");
									 $("#success").slideDown("slow");
								  </script>'; 	

						} else {

							$error = 'Je bent geen stafflid!';
							echo '<script type="text/javascript">
									 $("#code").addClass("wrong");
									 $("#error").html("'.$error.'");
									 $("#error").slideDown("slow");

									 setTimeout(function() {
									 	$("#code").removeClass("wrong");
									 	$("#error").html("");
									 	$("#error").slideUp("slow");
									 }, 3000);
								  </script>'; 

						}

					} else {

						$error = 'Veiligheidscode is onjuist!';
						echo '<script type="text/javascript">
								  $("#code").addClass("wrong");
								  $("#error").html("'.$error.'");
								  $("#error").slideDown("slow");

								  setTimeout(function() {
								  	 $("#code").removeClass("wrong");
									 $("#error").html("");
									 $("#error").slideUp("slow");
								  }, 3000);
							   </script>'; 

					}

				} else {

					$error = 'Veiligheidscode is ongeldig!';
					echo '<script type="text/javascript">
							 $("#code").addClass("wrong");
							 $("#error").html("'.$error.'");
							 $("#error").slideDown("slow");

							 setTimeout(function() {
							 	$("#code").removeClass("wrong");
								$("#error").html("");
								$("#error").slideUp("slow");
							 }, 3000);
						  </script>'; 

				}

			}
		?>		
		<script type="text/javascript">
<!--
function showSpoilers()
{
object = document.getElementById("spoiler");
object.disabled = true;
}
// --></script> 
	</body>
</html>