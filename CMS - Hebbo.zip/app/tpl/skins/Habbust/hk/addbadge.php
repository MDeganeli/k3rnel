<?php
	if($_SESSION["in_hk"] == false){
		header("Location: /me");
			exit();
	}

	$getUseRank4Page = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
	$perms = mysql_fetch_assoc(mysql_query("SELECT * FROM housekeeping_perms WHERE `perm` = 'perm_badge'"));
	if ($perms['rank'] > $getUseRank4Page['rank']){
		header("Location: index.php?url=main");
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>{hotelName} ASE - Add Badges</title>
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/css/theme.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="{url}/app/tpl/skins/{skin}/hk/scripts/ckeditor/ckeditor.js"></script>
		<script src="{url}/app/tpl/skins/{skin}/hk/scripts/ckeditor/adapters/jquery.js"></script>
</head>

<body>
	<?php include "includes/header.php"; ?>
		
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php include "includes/navigator.php"; ?>
				</div>
							
				<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Add Badge to Badge Shop</h3>
							</div>							
							<div class="module-body">
		
								<?php
									if($_SESSION['user']['rank'] >= 6)
									{
										if($_POST['badge']){
											
											$getFilter = mysql_query("SELECT * FROM `badge_shop` WHERE `badge_id` = '".$_POST['badge_id']."'");
											$filter = mysql_fetch_array($getFilter);
											
											if ($_POST['id'] == $filter['badge_id'])
											{
												echo '					
												<div class="alert alert-error">
													<button type="button" class="close" data-dismiss="alert">×</button>
													<strong>Error</strong> The badge <strong>'.$_POST['id'].'</strong> already exists in the badge shop!
												</div>';  						
											}
											else
											{
												$badge_id = $_POST['id'];
												$title = $_POST['title'];
												$desc = $_POST['desc'];
												$cost = $_POST['cost'];
												
												mysql_query("INSERT INTO badge_shop (`badge_id`,`title`,`description`,`cost`) VALUES ('".$badge_id."','".$title."','".$desc."','".$cost."')"); 
												echo '					
												<div class="alert alert-success">
													<button type="button" class="close" data-dismiss="alert">×</button>
													<strong>Well Done!</strong> The badge <strong>'.$_POST['id'].'</strong> is now apart of the badge shop!
												</div>';					
											}
											
										}
									}
								?>
		
								<form class="form-horizontal row-fluid" method="post">
									<div class="control-group">
										<label class="control-label" for="basicinput">Badge ID</label>
										<div class="controls">
											<input type="text" id="basicinput" name="id" placeholder="ADM" class="span8">
										</div>	
									</div>
									
									<div class="control-group">
										<label class="control-label" for="basicinput">Title</label>
										<div class="controls">
											<input type="text" id="basicinput" name="title" placeholder="Hotel Staff" class="span8">
										</div>	
									</div>

									<div class="control-group">
										<label class="control-label" for="basicinput">Description</label>
										<div class="controls">
											<input type="text" id="basicinput" name="desc" placeholder="I am staff at {hotelName} Hotel." class="span8">
										</div>	
									</div>	

									<div class="control-group">
										<label class="control-label" for="basicinput">Cost</label>
										<div class="controls">
											<input type="text" id="basicinput" name="cost" placeholder="5000" class="span8">
										</div>	
									</div>									
									
									<div class="control-group">
										<div class="controls">
											<input type="submit" name="badge" class="btn btn-primary">
										</div>
									</div>
								</form>
							
							</div>
						</div>
						
						<div class="module">
							<div class="module-head">
								<h3>Current Badges</h3>
							</div>
							<div class="module-body">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped  display dataTable" width="100%" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info" style="width: 100%;">
									<thead>
										<tr>
											<th>ID</th>
											<th>Title</th>
											<th>Description</th>
											<th>Cost</th>
											<th>Image</th>
										</tr>
									</thead>
									<tbody>										
									<?php
										$getBadges = mysql_query("SELECT * FROM badge_shop ORDER BY id ASC")or die(mysql_error());
										while ($badges = mysql_fetch_assoc($getBadges)){
										echo'
													<tr>
														<td>'. $badges['badge_id'] .'</td>
														<td>'. $badges['title'] .'</td>
														<td>'. $badges['description'] .'</td>
														<td>'. $badges['cost'] .'</td>
														<td><center><img src="/game/c_images/album1584/'. $badges['badge_id'] .'.gif" /></center></td>
													</tr>';
										}
									?>
									</tbody>
								</table>
							</div>
						</div>	
					</div>
				</div>
				
			</div>
		</div>
	</div>

	<?php include "includes/footer.php"; ?>
	
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/common.js" type="text/javascript"></script>
</body>