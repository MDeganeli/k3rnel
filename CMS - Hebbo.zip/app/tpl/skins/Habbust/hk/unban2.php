<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

    <title>{hk_name} - Unban a user!</title>

    <!-- Bootstrap core CSS -->
    <link href="http://getbootstrap.com/dist/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="http://getbootstrap.com/examples/navbar-static-top/navbar-static-top.css" rel="stylesheet">
  </head>

  <body>

    <!-- Static navbar -->
    <div class="navbar navbar-default navbar-static-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php?url=dash">{hk_name}</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="index.php?url=dash">Dash</a></li>
      <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">News Management<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li ><a href="news">Make a news article</a></li>
                <li class="active"><a href="delnews">Delete a news article</a></li>
                <li class="divider"></li>
              </ul>
            </li>
            <li class="active" class="dropdown" >
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ban Management<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="index.php?url=banlist">View the Banlist</a></li>
                <li class="active"><a href="unban">Unban a user!</a></li>
                <li class="divider"></li>
              </ul>
            </li>         
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">User Management<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="index.php?url=edit">Edit a users account!</a></li>
                <li class="divider"></li>
              </ul>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="index.php?url=logout">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-dashboard"></i> Someone banned by mistake? Unban them here!</li>
            </ol>
	</div>
          <div class="col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-clock-o"></i> Staff  Chat!</h3>
              </div>
              <div class="panel-body">
              <form action="unban2" method=POST>
              <input class = "btn btn-default" type=text name=id>
              <input type=submit value="Unban (Enter ban ID)" class = "btn btn-gray">
              </form>
<?php
if(isset($_POST['username'])){ 
mysql_query("DELETE FROM users_bans WHERE value = '" . $username . "'") or die(mysql_error()); 
echo("User ban has been deleted");
} 
else
{
echo("User ban not found. Please double check the ID and try again.");
}

?>
            <div class="alert alert-success alert-dismissable">
				<center>Okay. If you see 'User ban has been deleted' at the top, then it has completed successfully.</center>
			  </div>

                    <div class="text-right">
                  <a>Know of someone abusing this tool? Report to {owner1} or {owner2}</a>
              </div>
            </div>
          </div>
        </div>

<?php include ("includes/footer.php"); ?>  

    <!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>

  </body>
</html>
