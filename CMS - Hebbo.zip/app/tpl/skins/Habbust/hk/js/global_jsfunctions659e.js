jQuery.fn.textPlaceholder = function() {
    return this.each(function() {
        var b = this;
        if (b.placeholder && "placeholder" in document.createElement(b.tagName)) {
            return
        }
        var c = b.getAttribute("placeholder");
        var a = $(b);
        if (b.value === "" || b.value == c) {
            a.addClass("text-placeholder");
            b.value = c
        }
        a.focus(function() {
            if (a.hasClass("text-placeholder")) {
                this.value = "";
                a.removeClass("text-placeholder")
            }
        });
        a.blur(function() {
            if (this.value === "") {
                a.addClass("text-placeholder");
                this.value = c
            } else {
                a.removeClass("text-placeholder")
            }
        });
        b.form && $(b.form).submit(function() {
            if (a.hasClass("text-placeholder")) {
                b.value = ""
            }
        })
    })
};
var url = window.location.toString();
if (url.search("www.") != -1) {
    window.location = url.replace("www.", "")
}

function urlencode(a) {
    a = escape(a);
    return a.replace(/[*+\/@]|%20/g, function(b) {
        switch (b) {
            case "=":
                b = "%3D";
                break;
            case "*":
                b = "%2A";
                break;
            case "+":
                b = "%2B";
                break;
            case "/":
                b = "%2F";
                break;
            case "@":
                b = "%40";
                break;
            case "%20":
                b = "+";
                break;
            case "?":
                b = "%3F";
                break
        }
        return b
    })
}
var newURL;
var urlArray;

function makeURL(b) {
    b = b.replace("#!", "").replace("#", "");
    urlArray = b.split("/");
    var a = ".php?";
    b = "";
    for (i in urlArray) {
        if (urlArray[i] != "") {
            b = b + urlencode(urlArray[i]) + a;
            if (a == ".php?" || a == "&") {
                a = "="
            } else {
                a = "&"
            }
        }
    }
    return b.substr(0, b.length - 1)
}
var oldhash = "";
var pageincludepath = "pages/";

function checkhash() {
    if (oldhash != window.location.hash) {
        $(".content").html('<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%"><tr><td align="center" valign="middle"><img src="http://hubly.biz/housekeeping/skins/todo/img/loading.gif"></td></tr></table>');
        oldhash = window.location.hash;
        newURL = makeURL(window.location.hash);
        if (window.location.hash == "") {
            newURL = makeURL(GLOBAL_Homepage)
        }
        var b = ".content";
        var a = ".content_home";
        var d = "#content_home_container";
        var c = "#content_container";
        if (newURL.search("Home.php") != -1 || newURL.search("HxL.php") != -1 || newURL.search("Newsletter.php") != -1) {
            b = ".content_home";
            a = ".content";
            d = "#content_container";
            c = "#content_home_container"
        }
        $(a).fadeOut();
        $(d).fadeOut();
        $(c).fadeIn();
        $(b).fadeIn();
        $(b).load(pageincludepath + newURL, function() {
            $(".load").each(function() {
                $(this).load(pageincludepath + makeURL($(this).attr("id")) + "external=true")
            });
            $("input").textPlaceholder()
        })
    }
}
$(document).ready(function() {
    setInterval("checkhash();", 100)
});
jQuery.expr[":"].Contains = function(c, d, b) {
    return jQuery(c).text().toUpperCase().indexOf(b[3].toUpperCase()) >= 0
};

function search(b, a) {
    $(document).ready(function() {
        $(b).keyup(function() {
            var c = a + ":Contains('" + $(b).val() + "')";
            $(a).hide();
            $(c).each(function() {
                $(this).show()
            })
        })
    })
}
var alert_interval = 0;

function alert(a) {
    if ($("#alert_container").length == 0) {
        $("body").append('<div id="alert_container"></div>')
    }
    alert_interval = alert_interval + 1;
    $("#alert_container").append('<div id="' + alert_interval + '_alert" class="alert alert-warning">' + a + "</div>");
    setTimeout('$("#' + alert_interval + '_alert").fadeOut();', 10000)
}

function popup(a, d, c) {
    $(document).mousedown(function(f) {
        if (f.pageX < $(d).offset().left || f.pageX > ($(d).offset().left + $(d).outerWidth()) || f.pageY < $(d).offset().top || f.pageY > ($(d).offset().top + $(d).outerHeight())) {
            $(d).hide();
            $(this).unbind("mousedown")
        }
    });
    $(d).css("position", "absolute");
    if (typeof(c) == "undefined") {
        c = "bottom"
    }
    if (c != "absolute") {
        var b = $(a).offset().left - (($(d).outerWidth() - $(a).outerWidth()) / 2);
        if (b < 1) {
            b = $(a).offset().left
        }
        $(d).css("left", b);
        $(d).css("top", $(a).offset().top);
        if (c == "bottom") {
            $(d).css("top", $(a).offset().top + $(a).outerHeight())
        }
        if (c == "left") {
            $(d).css("left", $(a).offset().left - $(d).outerWidth())
        }
        if (c == "right") {
            $(d).css("left", $(a).offset().left + $(a).outerWidth())
        }
        if (c == "top") {
            $(d).css("top", $(a).offset().top - $(d).outerHeight())
        }
    }
    $(d).show()
}
var tooltip_handler_array = new Array();

function tooltip(a, c) {
    $(".tooltippopup").hide();
    var b = a.substr(1) + "_tooltip";
    $("body").append('<div class="popup tooltippopup" id="' + b + '">' + c + "</div>");
    var d = "#" + b;
    $(a).hover(function() {
        $(d).css("position", "absolute");
        $(d).css("left", $(this).offset().left - (($(d).outerWidth() - $(this).outerWidth()) / 2));
        $(d).css("top", $(this).offset().top - $(d).outerHeight() - 1);
        if ($(d).css("top") < 0) {
            $(d).css("top", 0)
        }
        $(d).show()
    }, function() {
        $(d).hide()
    });
    return d
}

function viewImage(a) {
    var b = $('<table onclick="$(this).remove();" id="viewImage_table" border="0" cellpadding="0" cellspacing="0" width="100%" height="100%"><tr><td align="center" valign="middle" id="viewImage"></td></tr></table>');
    $("body").prepend(b);
    $(b).find("#viewImage").html('<div style="display: none;"><img src="' + a + '"><div id="close">CLOSE</div></div>');
    $(b).find("#viewImage div").fadeIn()
}
var find_bbcode = new Array(/</im, /\[QUOTE\=(.*?);(.*?)\]/ig, /\[QUOTE\=(.*?)\]/ig, /\[QUOTE\]/ig, /\[\/QUOTE\]/ig, /\[\*\](.*?)\n/g, /\[center\]/gim, /\[\/center\]/gim, /\[left\]/gim, /\[\/left\]/gim, /\[right\]/gim, /\[\/right\]/gim, /\[u\]/gim, /\[\/u\]/gim, /\[b\]/gim, /\[\/b\]/gim, /\[strike\]/gim, /\[\/strike\]/gim, /\[i\]/gim, /\[\/i\]/gim, /\[img\](.*?)\[\/img\]/gi, /\[url\="?(.*?)"?\](.*?)\[\/url\]/i, /\[url\](.*?)\[\/url\]/i, /\[list=1\]([\s\S]*?)\[\/list\]/gim, /\[list\]([\s\S]*?)\[\/list\]/gim, /\n/gi, /\[size=(.*?)\]/gim, /\[\/size\]/gim, /\[font=(.*?)\]/gim, /\[\/font\]/gim, /\[color=(.*?)\]/gim, /\[\/color\]/gim, /\[spoiler\]/gim, /\[spoiler=(.*?)\]/gim, /\[\/spoiler\]/gim);
var replace_bbcode = new Array("&lt;", "<div class='quoted'><strong>$1:</strong><br>", "<div class='quoted'>", "<div class='quoted'>", "</div>", "<li>$1</li>", "<center>", "</center>", "<div align=left>", "</div>", "<div align=right>", "</div>", "<u>", "</u>", "<strong>", "</strong>", "<strike>", "</strike>", "<em>", "</em>", '<img src="$1" alt="An image">', '<a href="$1">$2</a>', '<a href="$1">$1</a>', "<ol>$1</ol>", "<ul>$1</ul>", "<br>", "<font size=$1>", "</font>", "<font face=$1>", "</font>", "<font color=$1>", "</font>", "<div><button onclick='$(this).hide();$(this).parent().find(\"div\").show();'>View Spoiler Contents</button><div style='display: none;'>", "<div><button onclick='$(this).hide();$(this).parent().find(\"div\").show();'>View Spoiler \"$1\" Contents</button><div style='display: none;'>", "</div></div>");

function parseBB(a) {
    if (a) {
        for (i = 0; i < find_bbcode.length; i++) {
            a = a.replace(find_bbcode[i], replace_bbcode[i])
        }
    }
    return a
}
var FUNCTIONREADY_INCRIMENT = 0;
var FUNCTIONREADY_ARRAY = new Array();

function doneTyping(a, d, b) {
    if (typeof(b) == "undefined") {
        b = 800
    }
    FUNCTIONREADY_INCRIMENT++;
    $(a).keydown(function() {
        clearTimeout(FUNCTIONREADY_ARRAY[FUNCTIONREADY_INCRIMENT])
    });
    var c = $(a);
    $(a).keydown(function() {
        FUNCTIONREADY_ARRAY[FUNCTIONREADY_INCRIMENT] = setTimeout(function() {
            d.call(c)
        }, b)
    })
}

function JSON(c, a, b, d) {
    $.ajax({
        url: c,
        type: a,
        data: b,
        cache: false,
        dataType: "json",
        success: function(f, e, g) {
            d(f, e)
        }
    })
}
var AUTOHEIGHTINTERVAL = new Array();
var AUTOHEIGHTINCRIMENT = 0;

function autoHeight(a) {
    $(a).each(function() {
        var c = this;
        $(c).attr("defaultheight", $(c).height()).attr("defaultwidth", $(c).width()).css("overflow-y", "hidden");
        var b = $('<div style="word-wrap: break-word; position: absolute; left: -9999px;"></div>').css({
            "font-size": $(c).css("font-size"),
            "font-family": $(c).css("font-family"),
            width: $(c).width()
        }).appendTo("body");
        var d = function() {
            $(b).html($(c).val().replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\n$/, "<br/>&nbsp;").replace(/\n/g, "<br />"));
            if ($(b).height() > $(c).attr("defaultheight")) {
                $(c).css("height", $(b).height())
            } else {
                $(c).css("height", $(c).attr("defaultheight"))
            }
        };
        $(c).keyup(d).keydown(d).change(d);
        d();
        var e = ++AUTOHEIGHTINCRIMENT;
        AUTOHEIGHTINTERVAL[e] = setInterval(function() {
            if ($(c).width() != $(c).attr("defaultwidth")) {
                $(c).attr("defaultwidth", $(c).width());
                $(b).css("width", $(c).width());
                d();
                if ($(c).width() == 0) {
                    $(b).remove();
                    clearInterval(AUTOHEIGHTINTERVAL[e])
                }
            }
        }, 300)
    })
}

function complexAlert(d, b, a, e) {
    var c = $("<table class='complexAlert' style='width: 100%; height: 100%; position: fixed; top: 0; left: 0;'> 							<tr valign='middle'> 								<td style='text-align: center;'> 									<div class='container'> 										<div class='alert'> 											<div class='alertTitle'>" + d + "</div> 											<div class='alertText'>" + b + "</div> 											<div class='alertOptions'>" + a + "</div> 										</div> 									</div> 								</td> 							</tr> 						</table>").appendTo("body");
    $(c).find("*[message]").click(function() {
        e.apply(c, [$(this).attr("message")])
    });
    return c
}

function complexAlert_dynamic(b, c) {
    var a = $("<table class='complexAlert' style='width: 100%; height: 100%; position: fixed; top: 0; left: 0;'> 							<tr valign='middle'> 								<td style='text-align: center;'> 									<div class='container'> 										<div class='alert'> 											<div class='alertContent'><center><img src='http://hubly.biz/housekeeping/skins/todo/img/loading.gif'></center></div> 										</div> 									</div> 								</td> 							</tr> 						</table>").appendTo("body");
    $(a).find(".alertContent").load(b, function() {
        $(a).find("*[message]").click(function() {
            var d = $(this);
            c.apply(a, [$(this).attr("message"), d])
        })
    });
    return a
}

function topAlert(c, a) {
    var b = $('<div class="topAlert_container"><div class="topAlert"><div class="container"><span class="title">' + c + '</span><span class="message">' + a + '</span><div class="close"></div></div></div><div class="topAlert_sudo"></div></div>');
    $("body").before(b);
    $(b).slideDown("slow");
    $(b).find(".topAlert").slideDown("slow");
    $(b).find(".close").click(function() {
        $(this).parent().parent().parent().slideUp("slow");
        $(this).parent().parent().parent().find(".topAlert").slideUp("slow");
        setTimeout(function() {
            $(this).parent().parent().parent().remove()
        }, 1000)
    })
}

function setCookie(a, d, b) {
    var e = new Date();
    e.setDate(e.getDate() + b);
    var c = escape(d) + ((b == null) ? "" : "; expires=" + e.toUTCString());
    document.cookie = a + "=" + c
}

function getCookie(b) {
    var c, a, e, d = document.cookie.split(";");
    for (c = 0; c < d.length; c++) {
        a = d[c].substr(0, d[c].indexOf("="));
        e = d[c].substr(d[c].indexOf("=") + 1);
        a = a.replace(/^\s+|\s+$/g, "");
        if (a == b) {
            return unescape(e)
        }
    }
};