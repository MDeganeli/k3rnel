	// LOGIN FUNCTIONS
		
		// PROCESS PANEL LOGIN
			function processLogin()
			{
				var loginUsername	= $('#login-username').val();
				var loginPassword	= $('#login-password').val();
				
				$.post('application/functions/process_login.php', { login_username: loginUsername, login_password: loginPassword},
   				function(data){
   					alert(data);
   					return 0;
   				});
   			}
   	
   	// KILL FUNCTIONS
   	
   		// KILL PANEL USER
   			function killStaff(userID)
			{
				$.post('application/functions/kill_functions.php', { type: "kill_staff_user", user_id: userID },
   				function(data){
   					alert(data);
   					return 0;
   				});
			}
		
		// KILL HOTEL USER
			function killUser(userID)
			{
				$.post('application/functions/kill_functions.php', { type: "kill_hotel_user", user_id: userID },
   				function(data){
   					alert(data);
   					return 0;
   				});
			}
			
	// HOTEL ALERT
		function hotelAlert()
		{
			var hotelMessage	= $('#hotel_message').val();
		
			$.post('application/functions/hotel_alert.php', { type: "hotel_alert", hotel_message: hotelMessage },
   			function(data){
   				alert(data);
   				return 0;
   			});
		}
		
	// WORD FILTER
	
		// ADD WORD
			function addWord()
			{
				var filterWord			= $('#word').val();
				var filterReplacement	= $('#replacement').val();
				var filterStrict		= $('#strict').val();
				
				$.post('application/functions/wordfilter_functions.php', { type: "add_word", word: filterWord, replacement: filterReplacement, strict: filterStrict},
   				function(data){
   					alert(data);
   					$('#word').val('');
   					$('#replacement').val('');
   					$('#strict').val('');
   					return 0;
   				});
   			}
   			
   		// DELETE WORD
   			function deleteWord(word)
   			{
   				$.post('application/functions/wordfilter_functions.php', { type: "delete_word", word: word},
   				function(data){
   					alert(data);
   					return 0;
   				});
   			}
   			
   	// RARE CATALOG EDITOR
   	
   	   			function searchRares(inputString)
			{
				if(inputString.length == 0)
				{
					$('#suggestions').fadeOut();
				}
					else
				{
					$.post('application/functions/auto_suggest_cata.php', {queryString: ""+inputString+""},
					function(data){
						if(data.length >0)
						{
							$('#suggestions').fadeIn();
							$('#suggestionsList').html(data);
						}
					});
				}
			}
			
			function fill(thisValue) {
				setTimeout("$('#suggestions').fadeOut();", 600);
			}
   			
   	// USER ACCOUNTS
   	
   		// AUTO SUGGEST USERS
   			function searchUsers(inputString)
			{
				if(inputString.length == 0)
				{
					$('#suggestions').fadeOut();
				}
					else
				{
					$.post('application/functions/auto_suggest_users.php', {queryString: ""+inputString+""},
					function(data){
						if(data.length >0)
						{
							$('#suggestions').fadeIn();
							$('#suggestionsList').html(data);
						}
					});
				}
			}
			
			function fill(thisValue) {
				setTimeout("$('#suggestions').fadeOut();", 600);
			}




// USER ACCOUNTS
   	
   		// AUTO SUGGEST USERS
   			function searchUsers2(inputString)
			{
				if(inputString.length == 0)
				{
					$('#suggestions2').fadeOut();
				}
					else
				{
					$.post('application/functions/auto_suggest_users_badge.php', {queryString2: ""+inputString+""},
					function(data){
						if(data.length >0)
						{
							$('#suggestions2').fadeIn();
							$('#suggestionsList2').html(data);
						}
					});
				}
			}
			
			function fill(thisValue) {
				setTimeout("$('#suggestions2').fadeOut();", 600);
			}

			
		// EDIT USER DETAILS
			function updateUserInfo()
			{
				var userID			= $('#user_id').val();
				var userEmail		= $('#user_email').val();
				var userRank		= $('#user_rank').val();
				var userCredits		= $('#user_credits').val();
				var userPixels		= $('#user_pixels').val();
				var userPoints		= $('#user_vip_points').val();
				var userMotto		= $('#user_motto').val();
				var userVIP			= $('#user_vip').val();
		
				$.post('application/functions/user_functions.php', { type: "update_user_info", user_id: userID, user_email: userEmail, user_rank: userRank, user_credits: userCredits, user_pixels: userPixels, user_vip_points: userPoints, user_motto: userMotto, user_vip: userVIP },
   				function(data){
					alert(data);
					return 0;
   				});
			}
			
		// EDIT USER STATS
			function updateUserStats()
			{
				var userID			= $('#user_id').val();
				var respectPoints	= $('#respect_points').val();
				var petPoints		= $('#pet_points').val();
				
				$.post('application/functions/user_functions.php', { type: "update_user_stats", user_id: userID, respect_points: respectPoints, pet_points: petPoints },
   				function(data){
					alert(data);
   					return 0;
   				});
			}
			
		// CHANGE USER PASSWORD
			function changePassword()
			{
				var userID				= $('#user_id').val();
				var newPassword			= $('#new-password').val();
				var confirmPassword		= $('#confirm-password').val();
				var sendEmail			= $('#send-email').val();
				
				$.post('application/functions/user_functions.php', { type: "change_user_password", user_id: userID, new_password: newPassword, confirm_password: confirmPassword, send_email: sendEmail},
   				function(data){
   					alert(data);
     				return 0;
     			});
			}
			
		// BAN USER
			function banUser()
   			{
   				var userID		= $('#user_id').val();
   				var ban_reason	= $('#reason').val();
   				var ban_length	= $('#ban_length').val();
   				
   				$.post('application/functions/ban_functions.php', { type: "ban", user_id: userID, ban_reason: ban_reason, ban_length: ban_length},
   				function(data){
   					alert(data);
   					return 0;
   				});
   			}
   			
   		// UNBAN USER
   			function unbanUser(userID)
   			{
   				$.post('application/functions/ban_functions.php', { type: "unban", user_id: userID },
   				function(data){
   					alert(data)
   					return 0;
   				});
   			}

   			
   	// USER REPORTS
   	
   		// ADD REPORT
   			function addReport()
			{
				var userID			= $('#user_id').val();
				var reportTitle 	= $('#report_title').val();
				var reportContent	= $('#report_content').val();
				
				$.post('application/functions/report_functions.php', { type: "add_report", user_id: userID, report_title: reportTitle, report_content: reportContent },
   				function(data){
   					alert(data);
   					return 0;
   				});
			}
			
		// REPLY REPORT
			function replyReport()
			{
				var replyID			= $('#report_id').val();
				var replyContent	= $('#reply_message').val();
				
				$.post('application/functions/report_functions.php', { type: "reply_report", report_id: replyID, reply_message: replyContent},
   				function(data){
					alert(data);
					return 0;
   				});
			}
			
		// DELETE REPORT
			function deleteReport(reportID)
			{
				$.post('application/functions/report_functions.php', { type: "delete_report", report_id: reportID},
   				function(data){
					alert(data);
					return 0;
   				});
			}
			
	// NEWS
	
		// POST ARTICLE
			function postArticle()
			{
				var articleTitle	= $('#article_title').val();
				var articleContent	= $('ckeditor').text();
				
				alert(articleContent);
				
				//$.post('application/functions/news_functions.php', { type: "add", article_title: articleTitle, article_content: articleContent},
   				//function(data){
					//alert(data);
					//return 0;
   				//});
			}
			