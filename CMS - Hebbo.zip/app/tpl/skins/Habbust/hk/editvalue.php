<?php
	if($_SESSION["in_hk"] == false){
		header("Location: /me");
			exit();
	}

	$getUseRank4Page = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
	$perms = mysql_fetch_assoc(mysql_query("SELECT * FROM housekeeping_perms WHERE `perm` = 'perm_filter'"));
	if ($perms['rank'] > $getUseRank4Page['rank']){
		header("Location: index.php?url=main");
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>{hotelName} ASE - Rare Values</title>
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/css/theme.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="{url}/app/tpl/skins/{skin}/hk/scripts/ckeditor/ckeditor.js"></script>
		<script src="{url}/app/tpl/skins/{skin}/hk/scripts/ckeditor/adapters/jquery.js"></script>
</head>

<body>
	<?php include "includes/header.php"; ?>
		
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php include "includes/navigator.php"; ?>
				</div>
							
				<div class="span9">
					<div class="content">
							
						<?php
							// Get ID of rare
							$id = intval($_GET['id']);
							
							// Get existing 
							$existq = mysql_query("SELECT * FROM cms_rarevalues WHERE id = '$id'") or die(mysql_error());
							$exist = mysql_num_rows($existq);
							$values = mysql_fetch_array($existq);
							
							$removeUnderscore = str_replace("_", " ", $values['rare_name']); // Remove any underscores and replace with a space
							$removeGif = str_replace(".gif", " ", $removeUnderscore); // Remove .gif from end of file name
							$rarename = ucwords(strtolower($removeGif)); // Make first letter of variable a capital. e.g "nelly gold" to "Nelly Gold"
							
							// If non-existing, redirect to /me
							if ($exist == 0) { header('Location: ../me'); }
						
							if (isset($_POST['submit'])) {
							
							// Define new variables
							$cost = mysql_real_escape_string($_POST['cost']);
							$userId = $_SESSION['user']['username'];
							$time = time();
							
							// If field is empty, tell the user
							if (empty($cost)) {
							echo '
							<div class="alert alert-error">
								<button type="button" class="close" data-dismiss="alert">×</button>
								<strong>Error</strong> Please fill in all fields!
							</div>';
							} else {
								mysql_query("UPDATE cms_rarevalues SET cost = '$cost', date_added = '$time', added_by = '$userId' WHERE id = '$id'") 
						or die(mysql_error());
						echo '
							<div class="alert alert-success">
								<button type="button" class="close" data-dismiss="alert">×</button>
								<strong>Success!</strong> News article updated. Redirecting you back to the Rare Values page...
							</div>';
							header( "refresh:3;url=/ase/values" );
							}
						}
						?>
									
						<div class="module">
							<div class="module-head">
								<h3>Edit Rare</h3>
							</div>
							<div class="module-body">
								<form method="post" class="form-horizontal row-fluid"> 			
									<div class="control-group">
										<label class="control-label" for="basicinput">Rare name</label>
										<div class="controls">
											<input type="text" id="basicinput" placeholder="<?php echo $rarename; ?>" class="span8" disabled>
										</div>
									</div>				

									<div class="control-group">
										<label class="control-label" for="basicinput">New Value</label>
										<div class="controls">
											<input type="text" id="basicinput" name="cost" placeholder="<?php echo $values['cost'] ?>" class="span8">
											<small class="muted"><strong>Old Value:</strong> <?php echo $values['cost'] ?></small>
										</div>
									</div>	
									
									<div class="control-group">
										<button type="submit" class="btn btn-small btn-primary" name="submit">Edit Value</button>
									</div>
								</form>
							</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>

	<?php include "includes/footer.php"; ?>
	
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/common.js" type="text/javascript"></script>
</body>