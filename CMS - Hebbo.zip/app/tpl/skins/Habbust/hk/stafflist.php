<?php
	if($_SESSION["in_hk"] == false){
		header("Location: /me");
			exit();
	}

	$getUseRank4Page = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
	$perms = mysql_fetch_assoc(mysql_query("SELECT * FROM housekeeping_perms WHERE `perm` = 'perm_stafflist'"));
	if ($perms['rank'] > $getUseRank4Page['rank']){
		header("Location: index.php?url=main");
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="shortcut icon" href="{url}/app/tpl/skins/{skin}/images/favicon.ico">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Make friends, join the fun, get noticed! - {hotelName}</title>
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/css/theme.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
</head>

<body>
	<?php 
		// Include Header
		include "includes/header.php"; 
	?>
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php 
						// Include Navigator
						include "includes/navigator.php";
					?>
				</div>
				
				<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Equipe Habbust</h3>
							</div>
							
							<div class="module-body">								
								<div class="row-fluid">
									<div class="span12">
										<?php							
											function time_elapsed_string($datetime, $full = false) {
												$now = new DateTime;
												$ago = new DateTime($datetime);
												$diff = $now->diff($ago);

												$diff->w = floor($diff->d / 7);
												$diff->d -= $diff->w * 7;

												$string = array(
													'y' => 'year',
													'm' => 'month',
													'w' => 'week',
													'd' => 'day',
													'h' => 'hour',
													'i' => 'minute',
													's' => 'second',
												);
												foreach ($string as $k => &$v) {
													if ($diff->$k) {
														$v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
													} else {
														unset($string[$k]);
													}
												}

												if (!$full) $string = array_slice($string, 0, 1);
												return $string ? implode(', ', $string) . ' ago' : 'just now';
											}
										
											$GetRanks = mysql_query("SELECT id,name FROM ranks WHERE id >=5 ORDER BY id DESC");
											while($Ranks = mysql_fetch_assoc($GetRanks))	
											{
												$GetUsers = mysql_query("SELECT * FROM users WHERE rank = {$Ranks['id']} ORDER by id");
												while($staff = mysql_fetch_array($GetUsers))
												{
													echo '
														<div class="media user">							
															<div class="media-body">															
																<a class="pull-left" href="#">
																	<img src="http://www.habbo.it/habbo-imaging/avatarimage?figure='. $staff['look'] .'&head_direction=3&direction=3&size=s">
																</a>															
																<h3 class="media-title">'. $staff['username'] .'</h3>
																<p style="float: left;">
																	<small class="muted">'. $Ranks['name'] .'</small><br />
																</p>
															</div>
														</div>
													';
													
												}
											}
										?>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<?php include "includes/footer.php"; ?>
		
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/common.js" type="text/javascript"></script>
</body>