 <?php 
		if($_SESSION['user']['rank'] >= 7){
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

    <title>{HotelName} - DashBoard</title>

    <!-- Bootstrap core CSS -->
    <link href="{url}/ase/bootstrap/css/bootstrap.css" rel="stylesheet">
   
  </head>

  <body>

    <!-- Static navbar -->
    <div class="navbar navbar-default navbar-static-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php?url=dash">{hotelName}</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active">
			<a href="index.php?url=dash">Início</a></li>
			<?php if($_SESSION['user']['rank'] > 8){ ?><li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Notícias<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="index.php?url=news">Criar uma notícia</a></li>
                <li><a href="index.php?url=delnews">Editar notícia</a></li>
              </ul>
            </li><?php } ?>        
<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Usuários<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="index.php?url=edit">Editar Usuário</a></li>
				<li><a href="index.php?url=hall">Dar ponto no Hall</a></li>
              </ul>
            </li>
          <ul class="nav navbar-nav navbar-right" style=" margin-right: 0px; ">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle dker" data-toggle="dropdown">
            			{username}<b class="caret">
            </b>
          </a>
		  		  <ul class="dropdown-menu">
            <li>
              <a href="{url}/client">
                Entrar no {hotelName}              </a>
            </li>
         <li>
              <a href="{url}">
                Voltar ao {hotelName}             </a>
          </ul>
		          </li>
      </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>


    <div class="container">
          <div class="col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-clock-o"></i> Editar Usuário</h3>
              </div>
              <div class="panel-body">
               	<style>
		input{
			height:25px;
			border:1px solid lightgray;
			border-radius:2px;
		}
		
		input[type='submit']{
		background-image:none;
		border:1px solid lightgray;
		line-height:20px;
		}
		.alert{
			height:25px;
			width:100%;
			background-color:#c73c3c;
			text-align:center;
			border-radius:1px;
			line-height:25px;
			color:#fff;
			font-weight:700;	
		}
	</style>
	<?php 
		$q_edituser = "INSERT INTO hk_logs (type, time, who_done) VALUES('Edit user(" . $_POST['username_current'] .")','". time() ."','{$_SESSION['user']['username']}')";
		if(isset($_POST['update']))
		{
			mysql_query($q_edituser);
			mysql_query("UPDATE users SET motto = '" . filter($_POST['motto']) . "', rank = '" . filter($_POST['rank']) . "', credits = '" . filter($_POST['credits']) . "', activity_points = '" . filter($_POST['pixels']) . "' WHERE username = '" . filter($_POST['username_current']) . "'") or die(mysql_error());
		   echo "<div class = \"alert\">" . $_POST['username_current'] . "'s account updated.</div>"; 
		}

		if(isset($_POST['lookup']))
		{	
		if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE username = '". filter($_POST['l_username']) ."'")) == 0) { echo "User does not exist."; }
		else { 
		$two = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE username = '" . filter($_POST['l_username']) . "'"));
	?>

	Editing account: <?php echo $username; ?></a>
	<form method='post' align = "center">
	<input type="hidden" name="username_current" value="<?php echo $_POST['l_username']; ?>" />
	
		<table align = "center" style="width: 100%;" align = "center">
				
			<tr>
				<td>Nome</td></td>
				<td><input type="text" value="<?php echo $_POST['l_username']; ?>"  disabled /></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" value="<?php echo $two['mail']; ?>"  disabled /></td>
			</tr>
			<tr>
				<td>Missão</td>
				<td><input type="text" name="motto" value="<?php echo $two['motto']; ?>"  /></td>
			</tr>
			<tr>
				<td>Rank</td>
				<td><input type="text" name="rank" value="<?php echo $two['rank']; ?>"></td>
			</tr>
			<tr>
				<td>Moedas</td>
				<td><input type="text" name="credits" value="<?php echo $two['credits']; ?>"  /></td>
			</tr>
			<tr>
				<td>Duckets</td>
				<td><input type="text" name="pixels" value="<?php echo $two['activity_points']; ?>"  /></td>
			</tr>
			<?php if($_POST['l_username'] == 'Test'){echo'IP viewing disabled for the \'Test\' user.';}
			else{?>
			<tr>
				<td>Registro de IP</td>
				<td><input type = "text" value = "<?php echo $two['ip_reg']; ?>" disabled></td>
			</tr>
			<tr>
				<td>Último IP</td>
				<td><input type = "text" value = "<?php echo $two['ip_last']; ?>" disabled></td>
			</tr>
			<?php } ?>
		</table>
		<input type="submit" value="  Salvar edição  " name="update"/>
	</form>
	<br />
	<?php
	}
	}
	?>
	<form method='post'>
	Nome <br /> <input type="text" name="l_username" /> <br /> <br />
	<input type="submit" value="  Procurar  " name="lookup"/>
	</form>
				<?php }
			else{
				die('Acesso Negado');
			}
			?>
<?php include ("includes/footer.php"); ?>  



    <!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>

  </body>
</html>