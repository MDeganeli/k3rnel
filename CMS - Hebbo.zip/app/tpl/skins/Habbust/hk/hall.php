<?php 
		// Include styles
		include "includes/style.php"; 
	?>
<body>
	<?php 
		// Include Header
		include "includes/header.php"; 
	?>
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php 
						// Include Navigator
						include "includes/navigator.php";
					?>
				</div>
     <div class="span9">
          <div class="content">
						<div class="module">
							<div class="module-head">
             <h3>Pontuar Hall da Fama</h3>
							</div>
							<div class="module-body">
<form method="post">

<h1>Dar Pontos de Eventos </h1>
<strong>Nome de Usuário</strong>
<br><input name="nomejogador" type="text" placeholder="Nome" />
<br>
<strong>Total de ponto a dar (1)</strong>
<br><input name="pontosevento" type="text"  placeholder="Pontos"/>
<br><br>
<input name="darponto" class="btn btn-success btn-smal" value="Inserir pontos de Eventos" type="submit" />
</form>
<?php
if (isset($_POST['darponto'])) {
$nomejogador = $_POST['nomejogador'];
$pontosevento = $_POST['pontosevento'];
$check = mysql_num_rows(mysql_query("SELECT * FROM rankevento WHERE nome = '$nomejogador'"));
if($check==0){
$adduser = mysql_query("insert into rankevento(nome, pontos) values('$nomejogador', '$pontosevento')");
echo("<br><div class='alert green'><center><span class='glyphicon glyphicon-info-sign'></span>Usuário inserido no ranking pois não havia nenhum ponto</center></div>");
}else{
$updatepontos = mysql_query("UPDATE rankevento SET nome = '$nomejogador', pontos = pontos+'$pontosevento' WHERE nome = '$nomejogador'") or die(mysql_error());
echo("<br><div class='alert green'><center><span class='glyphicon glyphicon-info-sign'></span>Pontos de $nomejogador foram atualizados</center></div>");
}
}
?><br>
<!-- PROMOÇÕES -->

<form method="post">
<hr>
<h1>Dar Pontos de Promoções </h1>
<strong>Nome de Usuário</strong>
<br><input name="nome" type="text" placeholder="Nome" />
<br>
<strong>Total de ponto a dar (1)</strong>
<br><input name="pontos" type="text"  placeholder="Pontos"/>
<br><br>
<input name="dar" class="btn btn-success btn-smal" value="Inserir pontos de campanha" type="submit" />
</form>
<?php
if (isset($_POST['dar'])) {
$nome = $_POST['nome'];
$pontos = $_POST['pontos'];
$check = mysql_num_rows(mysql_query("SELECT * FROM rankcampanha WHERE nome = '$nome'"));
if($check==0){
$adduser = mysql_query("insert into rankcampanha(nome, pontos) values('$nome', '$pontos')");
echo("<br><div class='alert green'><center><span class='glyphicon glyphicon-info-sign'></span>Usuário inserido no ranking pois não havia nenhum ponto</center></div>");
}else{
$updatepontos = mysql_query("UPDATE rankcampanha SET nome = '$nome', pontos = pontos+'$pontos' WHERE nome = '$nome'") or die(mysql_error());
echo("<br><div class='alert green'><center><span class='glyphicon glyphicon-info-sign'></span>Pontos de $nome foram atualizados</center></div>");
}
}
?><br><hr>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php include ("includes/footer.php"); ?> 
<!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>
  </body>
</html>