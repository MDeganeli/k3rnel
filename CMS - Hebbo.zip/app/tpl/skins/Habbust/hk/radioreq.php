<?php
	if($_SESSION["in_hk"] == false){
		header("Location: /me");
			exit();
	}

	$getUseRank4Page = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
	$perms = mysql_fetch_assoc(mysql_query("SELECT * FROM housekeeping_perms WHERE `perm` = 'perm_trialapps'"));
	if ($perms['rank'] > $getUseRank4Page['rank']){
		header("Location: index.php?url=main");
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>{hotelName} ASE - Staff Applications</title>
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/css/theme.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
</head>

<body>
	<?php 
		// Include Header
		include "includes/header.php"; 
	?>
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php 
						// Include Navigator
						include "includes/navigator.php";
					?>
				</div>
				
				<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Radio Requests</h3>
							</div>
							<div class="module-body">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped  display dataTable" width="100%" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info" style="width: 100%;">
									<thead>
										<tr>
											<th>ID</th>
											<th>Username</th>
											<th>Song</th>
											<th>Youtube Link</th>
											<th>Played</th>
											
										</tr>
									</thead>
									<tbody>										
									<?php
										$getApps = mysql_query("SELECT * FROM radio_requests WHERE played = 'No' ORDER BY id DESC")or die(mysql_error());
										while ($apps = mysql_fetch_assoc($getApps))
										{																					
											echo'
												<tr>
													<td>'. $apps['id'] .'</td>
													<td>'. $apps['user'] .'</td>
													<td>'. $apps['song'] .'</td>
													<td>'. $apps['yturl'] .'</td>
													
													<td><a href="/ase/index.php?url=radioreqedit&id='. $apps['id'] .'">Read More</a></td>		
												</tr>
											';
										}
									?>
									</tbody>
								</table>
							</div>
						</div>	

					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<?php include "includes/footer.php"; ?>
		
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/common.js" type="text/javascript"></script>
</body>