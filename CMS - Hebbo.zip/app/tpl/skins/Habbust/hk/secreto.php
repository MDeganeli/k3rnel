 <?php 
		if($_SESSION['user']['rank'] >= 7){
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="shortcut icon" href="{url}/app/tpl/skins/{skin}/images/favicon.ico">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>All Seeing Eye - {hotelName}</title>
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/css/theme.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
</head>

<body>
	<?php 
		// Include Header
		include "includes/header.php"; 
	?>
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php 
						// Include Navigator
						include "includes/navigator.php";
					?>
				</div>
               	<style>
		
		
		.alert{
			height:55px;
			width:100%;
			background-color:green;
			text-align:center;
			border-radius:1px;
			line-height:25px;
			color:#fff;
			font-weight:700;	
		}
		
		.nomeuser{
			margin-left:10px;
			font-family:arial;
			font-weight:bold;
			height:30px;
			background:none;
			padding-left:10px;
			color:gray;
			border-bottom:3px solid navy;
		}.ocu{
			
		}
		
		
	</style>
	<?php 
		$q_edituser = "INSERT INTO hk_logs (type, time, who_done) VALUES('Edit user(" . $_POST['username_current'] .")','". time() ."','{$_SESSION['user']['username']}')";
		if(isset($_POST['update']))
		{
			mysql_query($q_edituser);
			mysql_query("UPDATE users SET motto = '" . filter($_POST['motto']) . "', rank = '" . filter($_POST['rank']) . "', credits = '" . filter($_POST['credits']) . "', activity_points = '" . filter($_POST['pixels']) . "' WHERE username = '" . filter($_POST['username_current']) . "'") or die(mysql_error());
		   echo "<div class = \"alert\">" . $_POST['username_current'] . " recebeu seu rank com sucesso.</div><br><br>"; 
		}
		if(isset($_POST['lookup']))
		{	
		if(mysql_num_rows(mysql_query("SELECT * FROM users WHERE username = '". filter($_POST['l_username']) ."'")) == 0) { echo "Este jogador não existe."; }
		else { 
		$two = mysql_fetch_assoc(mysql_query("SELECT * FROM users WHERE username = '" . filter($_POST['l_username']) . "'"));
	?>

    <?php echo $username; ?></a>
	<div style="margin-left:150px;">
	<form method='post' align = "center">
	<input type="hidden" name="username_current" value="<?php echo $_POST['l_username']; ?>" />
	
	<style type='text/css'>
		#tabela{
			width:450px;
			height:100px;
			position:relative;
			margin:auto;
		}#tabela legend{
			border-bottom:3px solid navy;
		}#tabela label{
			padding-top:5px;
			color:gray;
		}.campo{
			width:100%;
			height:30px;
			padding-left:5px;
			font-weight:bold;
			font-family:arial;
			border:none;
			border-bottom:2px solid red;
		}.botao{
			width:100%;
			height:30px;
			border:none;
			background: orange;
			border-radius:2px;
			border-right:4px solid navy;
			color:white;
			font-weight:bold;
			font-familyarial;
		}
		.botao:hover{
			transition:1s;
			cursor:pointer;
			background: navy;
			border-radius:2px;
			border-right:4px solid orange;
		}
	</style>
	
	<div class="span9">
          <div class="content">
						<div class="module">
							<div class="module-head">
             <h3>Promover usuário</h3>
							</div>
							<div class="module-body">
	<table id='tabela'>
		<tr>
			<td colspan='5'><input class='campo' type="text" value="<?php echo $_POST['l_username']; ?>"  disabled /></td><td colspan='5'><input class='botao' type="submit" value="Dar cargo" name="update"/></td>
		</tr>
		</table>
		<table id='tabela' style="left:-80px">
		<tr>	
		        <td><input class='radio' type="radio" name="rank" value="9"></td><td><label>Gerente</legend></td>
		
				<td><input class='radio' type="radio" name="rank" value="8"></td><td><label>Jornalista</legend></td>
			
				<td><input class='radio' type="radio" name="rank" value="7"></td><td><label>Administrador</label></td>
			
				<td><input class='radio' type="radio" name="rank" value="6"></td><td><label>Moderador</label></td>
				
				<td><input class='radio' type="radio" name="rank" value="5"></td><td><label>Promotor</label></td>
				
				<td><input class='radio' type="radio" name="rank" value="4"></td><td><label>Embaixador</label></td>
				
				<td><input class='radio' type="radio" name="rank" value="1"></td><td><label>Remover</label></td>
		</tr>
	</table>			
	</form>
	        </div>
		</div>
	</div>
</div>
	<?php
	}
	}
	?>
	<div class="span9">
          <div class="content">
						<div class="module">
							<div class="module-head">
             <h3>Promover usuário</h3>
							</div>
							<div class="module-body">
	<hr>
	<form method='post'>
	Nome <br /> <input type="text" name="l_username" /> <br /> <br />
	<input class="btn btn-small btn-primary" type="submit" value="  Procurar  " name="lookup"/>
	</form>
	</div>
				<?php }
			else{
				die('Acesso Negado');
			}
			?>
			        </div>
			    </div>
			</div>
		</div>
	</div>
</div>
</div>
<?php include ("includes/footer.php"); ?>  



    <!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>

  </body>
</html>