<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="shortcut icon" href="{url}/app/tpl/skins/{skin}/images/favicon.ico">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>All Seeing Eye - {hotelName}</title>
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/css/theme.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
</head>

<body>
	<?php 
		// Include Header
		include "includes/header.php"; 
	?>
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php 
						// Include Navigator
						include "includes/navigator.php";
					?>
				</div>
			
				<div class="span9">
          <div class="content">
						<div class="module">
							<div class="module-head">
             <h3>Desbanir jogador</h3>
							</div>
							<div class="module-body">
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-dashboard"></i> Baniu alguém sem querer? Pode desbanir agora :)</li>
            </ol>
          <div class="content">
             <h3 style="margin-left:20px;">Desbanir jogador</h3>
              <div class="panel-body">
              <form action="unban2" method=POST>
              <input type=text name=id class = "btn btn-default">
              <input style="margin-top:-10px" class = "btn btn-gray" type=submit value="Desbanir (Coloque o nick)">
              </form>

                    <div class="text-right">
                  <a>Alguém está abusando dos comandos? Reportar para Killua</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
	 </div>
	</div>
</div>
</div>
    <?php include ("includes/footer.php"); ?>  


    <!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>

  </body>
</html>
