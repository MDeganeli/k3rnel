<?php if($_SESSION['user']['rank'] > 4){ ?>
<?php
if(isset($_SESSION['in_hk'])){
echo '<script>location.href="index.php?url=login";</script>';
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

    <title>{HotelName} - Login</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap1.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">

  </head>
  <body></br></br></br></br>
  <div class="content-wrapper">
    <div class="box">
        <center>
          <?php echo $template->form->error; ?>
        <h2 class="form-signin-heading"><font color = "#616161"> {HotelName} Login</font></h2>
        </center>
        
        <form class = "form-signin" method="post" action="index.php?url=login">
        <b>Nome de Usu&aacute;rio:</b> <br /> <input type="text" name="username" size="5" maxlength="15" class = "form-control" class="login"/>
        <b>Senha:</b> <br /> <input type="password" name="password" class = "form-control"class="login"/>
            <input type="submit" class="btn btn-lg btn-primary btn-block" value="Entrar" name="login" class = "form-control "class="login"/>
        </form>
</div></br></br>
<center style=" font-weight: 100; ">
<a href="#"> Todos os direitos ao </a><a href="#"> Habbust</a><br>
<div style="font-size: 11px;"> </div></center>
                    </div>
</body>

</html>
<?php } ?>