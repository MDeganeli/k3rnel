<?php
	if($_SESSION["in_hk"] == false){
		header("Location: /me");
			exit();
	}

	$getUseRank4Page = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
	$perms = mysql_fetch_assoc(mysql_query("SELECT * FROM housekeeping_perms WHERE `perm` = 'perm_eventha'"));
	if ($perms['rank'] > $getUseRank4Page['rank']){
		header("Location: index.php?url=main");
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>{hotelName} ASE - Event HA</title>
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/css/theme.css" rel="stylesheet">
	<link type="text/css" href="{url}/app/tpl/skins/{skin}/hk/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
</head>

<body>
	<?php 
		// Include Header
		include "includes/header.php"; 
	?>
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php 
						// Include Navigator
						include "includes/navigator.php";
					?>
				</div>
				
				<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Event Hotel Alert</h3>
							</div>
							<div class="module-body">

							<div class="alert alert-error">
								<button type="button" class="close" data-dismiss="alert">×</button>
								<strong>Warning</strong> Misuse of this tool may result in you getting <strong>fired</strong> from {hotelName} hotel.
							</div>
							
								<?php
									if($_SESSION['user']['rank'] >= 6)
									{
										if($_POST['eventha']){
											
											$id = $_SESSION['user']['id'];
											$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
											$time = time();
											$username = $_POST['username'];
											
											$getUser = mysql_query("SELECT * FROM users WHERE id = '". $_SESSION['user']['id'] ."' LIMIT 1");
											$user = mysql_fetch_assoc($getUser);
											$eventha = $user['eventha'];
											
											if($eventha < time() - 900){
												// Housekeeping Logs
												mysql_query("INSERT INTO cms_housekeeping_logs (`userid`,`ip_address`,`page`,`time`, `extra_data`) VALUES ('". $id ."','". $ip ."','Event Alert','".$time."', 'Search ". $username ." for events.')"); 
												
												// Update users HA time
												mysql_query("UPDATE `users` SET `eventha`='".$time."' WHERE (`id`='".$id."')");
												
												// Run MUS Command
												MUS(ha, "Search ". $username ." for events.\n\n - Sent via Housekeeping.");
												
												// Success message
												echo '
												<div class="alert alert-success">
													<button type="button" class="close" data-dismiss="alert">×</button>
													<strong>Well done!</strong> Event Hotel Alert sent. 
												</div>';

											} else {
												echo '
													<div class="alert alert-error">
														<button type="button" class="close" data-dismiss="alert">×</button>
														<strong>Warning</strong> Please wait <strong>15 minutes</strong> before using the <strong>Event HA</strong>.
													</div>
												';
											}
										}
									}
								?>
							
								<form class="form-horizontal row-fluid" method="post">						
									<div class="control-group">
										<label class="control-label" for="basicinput">Username</label>
										<div class="controls">
											<select placeholder="Select here.." name="username" class="span8">
												<?php
													$getUser = mysql_query("SELECT * FROM `users` WHERE `online` = '1' ORDER BY username");
													while ($user = mysql_fetch_assoc($getUser))
													{
														echo '<option value="'. $user['username'] .'">'. $user['username'] .'</option>';
													}
												?>
											</select>
										</div>								
									</div>

									<div class="control-group">
										<div class="controls">
											<input type="submit" name="eventha" class="btn btn-primary">
										</div>
									</div>
									
								</form>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<?php include "includes/footer.php"; ?>
		
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="{url}/app/tpl/skins/{skin}/hk/scripts/common.js" type="text/javascript"></script>
</body>