<?php
// Database config
$host = "localhost"; // Your database host, normaly localhost
$user = "root"; // Database username
$password = ""; // Your database password
$database = "magic"; // The name of the database on your server


mysql_connect('localhost', 'root', '') or die(mysql_error()); 
mysql_select_db('magic') or die(mysql_error()); 

?>