 <?php 
		if($_SESSION['user']['rank'] >= 7){
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

    <title>{hk_name} - Delete a News article!</title>

    <!-- Bootstrap core CSS -->
    <link href="{url}/ase/bootstrap/css/bootstrap.css" rel="stylesheet">

  </head>

  <body>

    <!-- Static navbar -->
    <div class="navbar navbar-default navbar-static-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php?url=dash">{hotelName}</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li>
			<a href="index.php?url=dash">Início</a></li>
			<?php if($_SESSION['user']['rank'] > 8){ ?><li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Notícias<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="index.php?url=news">Criar uma notícia</a></li>
                <li><a href="index.php?url=delnews">Editar notícia</a></li>
              </ul>
            </li><?php } ?>          
<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Usuários<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="index.php?url=edit">Editar Usuário</a></li>
				<li><a href="index.php?url=hall">Dar ponto no Hall</a></li>
              </ul>
            </li>
          <ul class="nav navbar-nav navbar-right" style=" margin-right: 0px; ">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle dker" data-toggle="dropdown">
            			{username}<b class="caret">
            </b>
          </a>
		  		  <ul class="dropdown-menu">
            <li>
              <a href="{url}/client">
                Entrar no {hotelName}              </a>
            </li>
         <li>
              <a href="{url}">
                Voltar ao {hotelName}             </a>
          </ul>
		          </li>
      </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>


    <div class="container">
<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Editar notícia</h3>
							</div>
							<div class="module-body">

								<?php
								if($do == "Delete" && is_numeric($news)){

	$check = mysql_query("SELECT id FROM cms_news WHERE id = '".$news."' LIMIT 1") or die(mysql_error());

	if(mysql_num_rows($check) > 0){
		$querynow = $db->query("DELETE FROM cms_news_new WHERE id = '{$getid}' LIMIT 1");
			$_SESSION['HK_GOOD_RETURN'] = "Not&iacute;cia deletada com sucesso!";
	}
		}

									$fetchNews = mysql_query("SELECT * FROM cms_news ORDER BY id DESC LIMIT 100");
									while ($news = mysql_fetch_array($fetchNews))
									{
										echo '<table class="table table-striped">';
											echo '<thead>';
												echo '<tr>';
													echo '<th>ID</th>';
													echo '<th>Título</th>';
													echo '<th>Descrição</th>';
													echo '<th>Publicada no dia</th>';
													echo '<th>Autor</th>';
													echo '<th>Editar</th>';
													echo '<th>Deletar</th>';
												echo '</tr>';
											echo '</thead>';
										
											echo '<tbody>';
												echo '<tr>';
													echo '<td width="5%">'. $news['id'] .'</td>';
													echo '<td width="20%">'. $news['title'] .'</td>';
													echo '<td width="25%">'. $news['shortstory'] .'</td>';
													echo '<td width="20%">' . date('l d F', $news['published']) . '</td>';
													echo '<td width="10%">'. $news['author'] .'</td>';
													echo '<td width="10%"><a href="index.php?url=editnews&id='.$news['id'].'" class="btn btn-small btn-primary">Editar</a></td>';
													echo '<td width="10%"><a href="index.php?url=delnews&id='.$news['id'].'" class="btn btn-small btn-primary">Deletar(off)</a></td>';
												echo '<tr/>';
											echo '</tbody>';
										echo '</table>';
														
									}
									
								?>						

								
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
		<?php } else{die('Ascesso Negado.');} ?>
		
<?php include ("includes/footer.php"); ?>  


    <!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>

  </body>
</html>