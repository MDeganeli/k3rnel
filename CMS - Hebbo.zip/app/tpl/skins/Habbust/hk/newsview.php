<?php
	if($_SESSION["in_hk"] == false){
		header("Location: /me");
			exit();
	}

	$getUseRank4Page = mysql_fetch_assoc(mysql_query("SELECT * FROM `users` WHERE `id` = '".$_SESSION['user']['id']."'"));
	$perms = mysql_fetch_assoc(mysql_query("SELECT * FROM housekeeping_perms WHERE `perm` = 'perm_editnews'"));
	if ($perms['rank'] > $getUseRank4Page['rank']){
		header("Location: index.php?url=main");
		die();
	}
		// Include styles
		include "includes/style.php"; 
	?>
<body>
	<?php include "includes/header.php"; ?>
		
	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="span3">
					<?php include "includes/navigator.php"; ?>
				</div>
							
				<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Editar notícias</h3>
							</div>
							<div class="module-body">

								<?php
									$fetchNews = mysql_query("SELECT * FROM cms_news ORDER BY id DESC");
									while ($news = mysql_fetch_array($fetchNews))
									{
										echo '<table class="table table-striped">';
											echo '<thead>';
												echo '<tr>';
													echo '<th>ID</th>';
													echo '<th>Título</th>';
													echo '<th>História curta</th>';
													echo '<th>Publicado em</th>';
													echo '<th>Autor</th>';
													echo '<th>Editar</th>';
												echo '</tr>';
											echo '</thead>';
										
											echo '<tbody>';
												echo '<tr>';
													echo '<td width="5%">'. $news['id'] .'</td>';
													echo '<td width="20%">'. $news['title'] .'</td>';
													echo '<td width="25%">'. $news['shortstory'] .'</td>';
													echo '<td width="20%">' . date('l d F', $news['published']) . '</td>';
													echo '<td width="10%">'. $news['author'] .'</td>';
													echo '<td width="10%"><a href="index.php?url=editnews&id='.$news['id'].'" class="btn btn-small btn-primary">Editar</a></td>';
												echo '<tr/>';
											echo '</tbody>';
										echo '</table>';
														
									}
								?>						

								
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>

	<?php include "includes/footer.php"; ?>
	<!-- JavaScript -->
    <script src="bootstrap/js/jquery-1.10.2.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>

    <!-- Page Plugins -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="bootstrap//morris/chart-data-morris.js"></script>
    <script src="bootstrap/js/tablesorter/jquery.tablesorter.js"></script>
    <script src="bootstrap/js/tablesorter/tables.js"></script>
</body>