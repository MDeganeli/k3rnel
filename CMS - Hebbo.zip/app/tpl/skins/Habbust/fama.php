<?php
$pagename = "Hall da Fama";
$pageid = "4";
include("includes/cabeca.php");
include("includes/menusite.php");
?>
<div class="container">
			
			<div class="row">
    <div class="col-xs-12 col-md-4">			
			<div style="width:350px; margin-left:625px;" class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16">
						<div class="module-header colorRed">
						<i class="fa fa-star fa-lg" style="float:right"></i>TOP 5 Eventos
						</div>
						<div id="contentBox" class="activity borderRed">
<div style="padding-left:5px; padding-right:5px;"><?php
$rank = "SELECT * FROM rankevento ORDER BY pontos DESC LIMIT 5";
$resranking = mysql_query($rank) or die(mysql_error());
$verifica = mysql_num_rows(mysql_query("SELECT * FROM rankevento"));
if($verifica!=0){
$i=1;
while($row=mysql_fetch_array($resranking)){

$mostralook = mysql_query(sprintf("SELECT look FROM users WHERE username = '%s'", $row[nome]));
$mostralook = mysql_fetch_assoc($mostralook);
$mostralook = $mostralook['look']; 
?>
<table width="452" border="0">
  <tr>
  <td width="50" valign="top"><div style="background:url(http://habbo.com.tr/habbo-imaging/avatarimage?figure=<?php echo $mostralook; ?>) -10px -14px; width:50px; height:60px;"></div></td>
    <td width="392" valign="top"><b>Nome:</b> <?php echo $row['nome']; ?><br />
     <b>Pontos:</b> <?php echo $row['pontos']; ?><br />
      <br />
	  </td>
  </tr>
</table>
<hr style="border:#ccc 1px dotted;" />
<?php
$i++;
}
}else{
echo("<table width='288' border='0'>
  <tr>
    <td width='57'><img src='http://i.imgur.com/TF4HY8u.gif' width='57' height='85' /></td>
    <td width='221' valign='top'>At&eacute; agora n&atilde;o houve nenhum evento no Hotel...
      <hr style='border:#ccc 1px dotted;' />
      <a href='#'>Saiba mais deste sistema lendo esta  not&iacute;cia</a>. </td>
  </tr>
</table>
");
}
?>
                </div>
            </div>
        </div>
    </div>
</div>
	<div class="col-xs-12 col-md-4">			
			<div style="width:350px; margin-left:610px;" class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16">
						<div class="module-header colorRed">
						<i class="fa fa-star fa-lg" style="float:right"></i>TOP 5 Promoções
						</div>
						<div id="contentBox" class="activity borderRed">
<div style="padding-left:5px; padding-right:5px;"><?php
$rank = "SELECT * FROM rankcampanha ORDER BY pontos DESC LIMIT 5";
$resranking = mysql_query($rank) or die(mysql_error());
$verifica = mysql_num_rows(mysql_query("SELECT * FROM rankcampanha"));
if($verifica!=0){
$i=1;
while($row=mysql_fetch_array($resranking)){

$mostralook = mysql_query(sprintf("SELECT look FROM users WHERE username = '%s'", $row[nome]));
$mostralook = mysql_fetch_assoc($mostralook);
$mostralook = $mostralook['look']; 
?>
<table width="452" border="0">
  <tr>
    <td width="50" valign="top"><div style="background:url(http://habbo.com.tr/habbo-imaging/avatarimage?figure=<?php echo $mostralook; ?>) -10px -14px; width:50px; height:60px;"></div></td>
    <td width="392" valign="top"><b>Nome:</b> <?php echo $row['nome']; ?><br />
     <b>Pontos:</b> <?php echo $row['pontos']; ?><br />
      <br /></td>
  </tr>
</table>
<hr style="border:#ccc 1px dotted;" />
<?php
$i++;
}
}else{
echo("<table width='288' border='0'>
  <tr>
    <td width='57'><img src='http://i.imgur.com/TF4HY8u.gif' width='57' height='85' /></td>
    <td width='221' valign='top'>Ainda n&atilde;o temos ganhadores de nenhuma promo&ccedil;&atilde;o..
      <hr style='border:#ccc 1px dotted;' />
      <a href='#'>Saiba mais deste sistema lendo esta  not&iacute;cia</a>. </td>
  </tr>
</table>
");
}
?>
                    </div>
				</div>
			</div>
		</div>
   	</div>
</div>	
    </div>
    <div class="col-xs-12 col-md-7">
									
			<div style="margin-left:-310px;width:530px;" class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16">
						<div class="module-header">Hall da Fama</div>
						<div id="contentBox" style="border-top: 2px solid #22B7B7;" class="activity">
      		</div>	
				<div class="media" style="width:500px; background-image:url(   );background-size: 100%;margin-top: 0;">
				<center style="color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; line-height: normal;">
<p style="margin: 0px; padding-bottom: 1em;"><img alt="" src="http://i.imgur.com/0rSOx0n.png" style="border: 0px; margin-top:10px; width: 428px; height: 242px;" /></p>
</center>

<p style="margin: 10px; padding-bottom: 1em; color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; line-height: normal;">O Hall da Fama&nbsp;foi criado com o intuito de promover os usu&aacute;rios que mais se sobressaem nas atividades proporcionadas pela Equipe Staff. A &uacute;nica maneira de entrar no&nbsp;<em>TOP5</em>&nbsp;de qualquer categoria, &eacute;&nbsp;participando ativamente, sejam elas promo&ccedil;&otilde;es ou eventos do dia-a-dia.</p>

<p style="margin: 10px; padding-bottom: 1em; color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; line-height: normal;">Quando falamos sobre as promo&ccedil;&otilde;es, tanto faz as mesmas serem de quarto, pixel-art, foto, a&uacute;dio e/ou v&iacute;deo, quarto, texto e/ou desenho,&nbsp;a mesma s&oacute; ir&aacute; lhe propor um ponto nessa categoria caso esteja afirmando na not&iacute;cia do concurso&nbsp;que ir&aacute; valer com o s&iacute;mbolo.</p>

<p style="margin: 10px; padding-bottom: 1em; color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: normal;"><strong>Ahh! j&aacute; n&atilde;o podendo esquecer...</strong></p>

<p style="margin: 10px; padding-bottom: 1em; color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; line-height: normal;"><strong>&raquo;</strong> Os pontos s&atilde;o acumulados desde o primeiro dia do m&ecirc;s;<br />
<strong>&raquo;</strong> Os concursos que vale ponto são identificados com o símbolo;<img alt="" src="http://i.imgur.com/KjAszVr.png" style="width: 12px; height: 15px; float: right;" /><br />
<strong>&raquo;</strong> Os usuários que estiverem em primeiro lugar no fim ganharão a premiação.</p>

<p style="margin: 10px; padding-bottom: 1em; color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; line-height: normal;">O Hall &eacute; zerado no 1&ordm; dia de cada m&ecirc;s, sendo assim os usu&aacute;rios que estiverem no&nbsp;<strong>TOP1</strong>&nbsp;de cada categoria, levam um emblema de bronze, prata ou ouro,&nbsp;dependendo da quantidade de vezes que ficou no topo. J&aacute; os demais, ser&atilde;o&nbsp;destacados em uma breve not&iacute;cia como merecimento.</p>

<p style="margin: 10px; padding-bottom: 1em; color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; line-height: normal;">A premiação de eventos consiste em emblemas games, e então após zerar os 100 níveis passa a receber pontos na tabela "Eventos" que futuramente juntando quantidades poderá trocar por raros. Confira nas notícias os emblemas que serão utilizados na premiação este mês.</p>

<p style="margin: 10px; padding-bottom: 1em; color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; line-height: normal;"><img alt="" src="http://images.habbohotel.com/c_images/album1584/DE229.gif" style="border: 0px; width: 41px; height: 41px;" />&nbsp;<img alt="" src="http://images.habbohotel.com/c_images/album1584/DE228.gif" style="border: 0px; width: 41px; height: 41px;" />&nbsp;<img alt="" src="http://images.habbohotel.com/c_images/album1584/DE227.gif" style="border: 0px; width: 41px; height: 41px;" />&nbsp;<img alt="" src="http://images.habbohotel.com/c_images/album1584/DE374.gif" style="border: 0px; float: right; width: 40px; height: 40px;" /><img alt="" src="http://images.habbohotel.com/c_images/album1584/DE377.gif" style="border: 0px; float: right; width: 40px; height: 40px;" /><img alt="" src="http://images.habbohotel.com/c_images/album1584/DE376.gif" style="border: 0px; width: 40px; height: 40px; float: right;" /></p>
				</div>
		</div>
    </div>
</div>
	</div>
<?php  include_once("includes/footer.php"); ?>