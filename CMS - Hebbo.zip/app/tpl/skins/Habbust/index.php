<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="Hart&Killua">
	<title>{hotelName} - {hoteldesc}</title>

<?php  include_once("includes/styles.php"); ?>
</head>
<?php  include_once("includes/menuindex.php"); ?>
<body>

	<div class="jumbotron container-jumbo">
	<?php if(isset($template->form->error)) { echo '<div class="alert alert-danger"><center><span class="glyphicon glyphicon-info-sign"></span> '.$template->form->error.'</center></div>'; } ?>
	<div class="container">
		<div class="row">
			<div class="col-sm-4">
				<div class="hotel"><img src="{url}/content/skin/Gold/assets/img/header.png" style="width:100%;visibility:hidden;"></div>
			</div>
			<div class="col-sm-7 text-center content-registro">
				<div class="form-group">
					<div class="col-sm-offset-4 col-sm-8">
						<span style="font-size:35px">Ainda não tem uma conta?</span><br/>Crie agora mesmo de Graça!<br><br>
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-4 col-sm-8">
						<a href="{url}/register" type="submit" class="btn btn-success botao-registrar">Criar uma Conta</a>
					</div>
				</div>
			</div>
		</div>			
	</div>
</div>

<div class="container">
	<div class="col-sm-offset-1 col-xs-12 col-sm-3" style="margin-right: 15px;">
		<div class="row">
			<div class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16" style="border-bottom: 2px solid #A27C1D;">
						<div class="module-header colorPink">
							<img src="{url}/content/skin/Gold/assets/img/coins.png" style="margin-top:5px;float:right"> Top Moedas
						</div>
					</div>
				</div>
<?php
$e = mysql_query("SELECT username,look,credits,id FROM users WHERE rank < 5 ORDER BY credits DESC LIMIT 5");
while($f = mysql_fetch_array($e)){
?>
<a class="list-group-item" style="text-decoration: none;" href="{url}/profile/<?php echo $f['username']; ?>">
						<div class="media">
							<div class="media-left">
								<div style="background-image: url(http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $f['look']; ?>&amp;size=m&amp;direction=2&amp;head_direction=2&amp;gesture=sml&img_format=png); background-position: -2px -17px; width:50px; height:50px;">
								</div>
							</div>
							<div class="media-body">
								<b><?php echo $f['username']; ?></b> &nbsp;
								<br><span class="currency credits"><?php echo $f['credits']; ?></span>
							</div>
						</div>
					</a>
<?php } ?>
			</div>
		</div>
	</div>

	<div class="col-xs-12 col-sm-3" style="margin-right: 15px;">
		<div class="row">
			<div class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16" style="border-bottom: 2px solid #B275B3;">
						<div class="module-header colorBeige">
							<img src="{url}/content/skin/Gold/assets/img/duckets.png" style="margin-top: 4px;float:right"> Top Duckets
						</div>
					</div>
				</div>
<?php
$e = mysql_query("SELECT username,look,activity_points,id FROM users WHERE rank < 5 ORDER BY activity_points DESC LIMIT 5");
while($f = mysql_fetch_array($e)){
?>
<a class="list-group-item" style="text-decoration: none;" href="{url}/profile/<?php echo $f['username']; ?>">
						<div class="media">
							<div class="media-left">
								<div style="background-image: url(http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $f['look']; ?>&amp;size=m&amp;direction=2&amp;head_direction=2&amp;gesture=sml&img_format=png); background-position: -2px -17px; width:50px; height:50px;">
								</div>
							</div>
							<div class="media-body">
								<b><?php echo $f['username']; ?></b> &nbsp;
								<br><span class="currency activity_points"><?php echo $f['activity_points']; ?></span>
							</div>
						</div>
					</a>
<?php } ?>
			</div>
		</div>
	</div>

	<div class="col-xs-12 col-sm-3" style="margin-right: 15px;">
		<div class="row">
			<div class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16" style="border-bottom: 2px solid #DB0000;">
						<div class="module-header colorDiamond">
							<img src="{url}/content/skin/Gold/assets/img/pipocas.gif" style="margin-top: 4px;float:right"> Top Pipocas
						</div>
					</div>
				</div>
<?php
$e = mysql_query("SELECT username,look,vip_points,id FROM users WHERE rank < 5 ORDER BY vip_points DESC LIMIT 5");
while($f = mysql_fetch_array($e)){
?>
<a class="list-group-item" style="text-decoration: none;" href="{url}/profile/<?php echo $f['username']; ?>">
						<div class="media">
							<div class="media-left">
								<div style="background-image: url(http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $f['look']; ?>&amp;size=m&amp;direction=2&amp;head_direction=2&amp;gesture=sml&img_format=png); background-position: -2px -17px; width:50px; height:50px;">
								</div>
							</div>
							<div class="media-body">
								<b><?php echo $f['username']; ?></b> &nbsp;
								<br><span class="currency pipocas"><?php echo $f['vip_points']; ?></span>
							</div>
						</div>
					</a>
<?php } ?>
			</div>
		</div>
	</div>
</div>
<?php  include_once("includes/footer.php"); ?>