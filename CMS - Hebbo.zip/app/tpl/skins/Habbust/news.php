<?php
$pagename = Notícias;
$pageid = "4";
include("includes/cabeca.php");
include("includes/menusite.php");
?>
<body>
		<div class="container">
			
			
<div class="container">

  
<div class="col-md-3">
  <div class="panel panel-primary">
    <div class="panel-body">
      <div class="grid_16" style="border-bottom: 2px solid #B275B3;">
        <div class="module-header colorPink">
        <i class="fa fa-newspaper-o fa-lg" style="margin-top: 4px;float:right"></i> Mais Notícias
        </div>
    </div>
    </div>
    <div class="list-group news">
<?php
$to5 = mysql_query("SELECT * FROM cms_news ORDER BY ID DESC LIMIT 10") or die(mysql_error());
 
   
?>
 
<?php $i = 0; while($newsobject = mysql_fetch_assoc($to5)){ $i++; ?>
 
<a href="{url}/article/<?php echo $newsobject['id']; ?>" class="list-group-item">
<h4 class="list-group-item-heading"><?php echo $newsobject['title']; ?></h4>

</a>
 
<?php }?>
       
    </div>
  </div>
</div>


  <div class="col-md-9">
    
    <div class="panel panel-primary">
      <div class="panel-body">
        <div class="grid_16">
          <div class="module-header colorGreen">
            <div class="avatar-head"style="background-image: url(http://www.habbo.com.br/habbo-imaging/avatarimage?figure={newsLook}&amp;direction=2&amp;head_direction=3&amp;gesture=sml&amp;size=p&amp;img_format=png);"></div> {newsTitle}
          </div>
        </div>
        <div id="contentBox" class="activity borderGreen">
         
          <div class="posted-by">
            <small>Notícia postada em <b>{newsDate}</b> por <b>{newsAuthor}</b></small>
          </div>
            {newsContent}
 </div>
     </div>
   </div>
 </div>
<?php  include_once("includes/footer.php"); ?>