<!DOCTYPE html>
<?php 
$pagename = "Nossa Equipe";
$pageid = "4";
include("includes/cabeca.php");
include("includes/menusite.php");

$userinfo = mysql_query("SELECT * FROM users WHERE username='$username' or id='$userid'");
$get2 = mysql_fetch_assoc($userinfo);

$user = $get2['username'];
$id = $get2['id'];
$looks = $get2['look'];
$email = $get2['mail'];
$rank = $get2['rank'];
$motto = $get2['motto'];
$credits = $get2['credits'];
$pixels = $get2['activity_points'];
$pvip = $get2['seasonal_currency'];
$online = $get2['online'];
$created = $get2['account_created'];
$lonline = $get2['last_online'];
$youtube = $get2['youtube'];
$staff = $get2['staff'];
?>
<body>
		<div class="container">
			
				<div class="row">
		<div class="col-xs-12 col-md-7">
									
			<div class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16">
						<div class="module-header">CEO</div>
						<div id="contentBox" style="border-top: 2px solid #22B7B7;" class="activity">
<?php
$e = mysql_query("SELECT * FROM users WHERE rank='9' ORDER BY id DESC");
while($f = mysql_fetch_array($e)){
?>																						<div>
								<div class="habbo-member" style="background:url(http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $f['look'] ?>&direction=2&head_direction=3&action=wav&size=b&gesture=sml&img_format=png) no-repeat -12px -19px;"></div>
								<a href="#" class="admin-name"><?php echo $f['username'] ?></a>
								<span class="admin-online  online"></span>
								<br><br>
								<span class="admin-desc"><?php echo $f['motto'] ?></span>
								<span class="admin-position"><?php echo $f['staff'] ?></span>
								<img src="{url}/swf/c_images/album1584/bust.gif" class="badge-staff">
							</div>
							<hr class="admin-trenn">
										<?php } ?>							
						</div>
					</div>
				</div>
			</div>
												
			<div class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16">
						<div class="module-header">Jornalista</div>
						<div id="contentBox" style="border-top: 2px solid #5FE464;" class="activity">
<?php
$e = mysql_query("SELECT * FROM users WHERE rank='7' ORDER BY id DESC");
while($f = mysql_fetch_array($e)){
?>																						<div>
								<div class="habbo-member" style="background:url(http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $f['look'] ?>&direction=2&head_direction=3&action=wav&size=b&gesture=sml&img_format=png) no-repeat -12px -19px;"></div>
								<a href="#" class="admin-name"><?php echo $f['username'] ?></a>
								<span class="admin-online  online"></span>
								<br><br>
								<span class="admin-desc"><?php echo $f['motto'] ?></span>
								<span class="admin-position"><?php echo $f['staff'] ?></span>
								<img src="{url}/swf/c_images/album1584/bust.gif" class="badge-staff">
							</div>
							<hr class="admin-trenn">
									<?php } ?>									
						</div>
					</div>
				</div>
			</div></div>
		<div class="col-xs-12 col-md-4">			
			<div class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16">
						<div class="module-header colorRed">
						<i class="fa fa-question fa-lg" style="float:right"></i>O que é Hebbust Staff
						</div>
						<div id="contentBox" class="activity borderRed">
							Estamos prontos para lhes ajudar com qualquer dúvida, problema, bug ou coisas desse tipo. Mas se acaso necessitar de ajuda imediata, nossos Ajudantes estão sempre de prontidão para que possa lhes ajudar.		
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php  include_once("includes/footer.php"); ?>