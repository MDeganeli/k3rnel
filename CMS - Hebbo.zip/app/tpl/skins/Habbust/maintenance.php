<!DOCTYPE html>
<html lang="pt">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="Helpi&Luck">
	<title>{hotelName} - Manutenção</title>

<?php  include_once("includes/styles.php"); ?>
</head>
	<body>
		<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only" style="top: 8px;position: absolute;">Menu</span>
                <span class="icon-bar" style="color:#fff;margin-right: 39px;"></span>
                <span class="icon-bar" style="color:#fff;margin-right: 39px;"></span>
                <span class="icon-bar" style="color:#fff;margin-right: 39px;"></span>
            </button>
            <a class="navbar-brand" href=""><div class="logo"></div></a>
        </div>

<div id="navbar" class="navbar-collapse collapse">
    <ul class="nav navbar-nav">
                <li><a href=""><i class="fa fa-home"></i> Logar</a></li>
        <li><a href="/register"><i class="fa fa-user"></i> Criar Conta</a></li>
        
            </div>
</div>
</nav>
		<div class="container">
			
			<div class="row">
    <div class="col-md-8">
      <div class="panel panel-primary">
        <div class="panel-heading" style="background-color: #B7588D;">
          <h2 class="panel-title"><i class="fa fa-wrench" style="float:right"></i> {hotelName} em manutenção!</h2>
        </div>
            <div class="panel-body">
        Infelizmente o Habbust no momento se encontra em <b>manutenção</b>!<br> Mas não se preocupe, voltaremos rapidamente!<br><br>Volte em breve para ver se terminamos ou simplesmente fique ligado em nosso <a href="https://www.facebook.com/HotelHabbust" target="_new">Facebook</a>
            </div>
       </div>

    </div>
<div class="habbo-container col-md-3">
      <div class="panel panel-primary">
        <div class="panel-heading" style="background-color: #43609C;">
          <h3 class="panel-title"><i class="fa fa-facebook-official" style="float:right"></i> Facebook</h3>
      </div>
        <div class="panel-body">
          
    </div>
   </div>
  </div>
</div>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.4&appId=1429224337348383";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<?php  include_once("includes/footer.php"); ?>
		</div>
	</body>
</html>