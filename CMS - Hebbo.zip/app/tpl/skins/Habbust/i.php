<?php  
if($_SESSION['user']['id']){

}
else{

Header("location: index.php");
exit;
 }
	?>
			<html>
				<head>
					<style>
						body {
							margin:0px;
							padding:0px;
							font:12px 'Lucida Grande',Arial,sans-serif;
							background-color:#000000;
						}
						.box {
							width:300px;
							margin:30px auto;
							background-color:#fff;
							border:1px solid #dcdada;
							padding:5px;
							-webkit-border-radius: 4px;
							-moz-border-radius: 4px;
							border-radius: 4px;
						}
						.error {
							background-color:#ffbcbb;
							border:1px solid #ff7777;
							padding:8px;
							margin-bottom:4px;
						}
						input {
							padding:4px;
						}
						input[type=password] {
							border:1px solid #dcdada;
							width:230px;
							-webkit-border-radius: 4px;
							-moz-border-radius: 4px;
							border-radius: 4px;
						}
						input[type=submit] {
							width:65px;
						}
					</style>
				</head>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Hebbust - Jogar</title>
<link rel="shortcut icon" type="img/png" href="/content/skin/Gold/assets/img/icons/gold.png">
<link rel="stylesheet" href="http://hebbust.com.br/app/tpl/skins/Habbust/style/client.css" type="text/css">

<script type="text/javascript" src="http://hebbust.com.br/app/tpl/skins/Habbust/js/swfobject.js"></script>
<script type="text/javascript">
var BaseUrl = "http://hebbust.com.br/swf/gordon/HABBUST/";
var flashvars =
{ 
"client.allow.cross.domain" : "1", 
"client.notify.cross.domain" : "0", 
"connection.info.host" : "149.56.89.212",
"connection.info.port" : "1232", 
"site.url" : "http://hebbust.com.br", 
"url.prefix" : "http://hebbust.com.br", 
"client.reload.url" : "http://hebbust.com.br/client", 
"client.fatal.error.url" : "http://hebbust.com.br/disconnected",
"logout.url" : "http://hebbust.com.br/disconnected", 
"logout.disconnect.url" : "http://hebbust.com.br/disconnected", 
"client.connection.failed.url" : "http://hebbust.com.br/disconnected",
"external.variables.txt" : "http://hebbust.com.br/swf/gamedata/external_variables/variables.txt", 
"external.texts.txt" : "http://hebbust.com.br/swf/gamedata/external_flash_texts/text_updated.txt",  
"productdata.load.url" : "http://hebbust.com.br/swf/gamedata/productdata/product_updated.txt", 
"furnidata.load.url" : "http://hebbust.com.br/swf/gamedata/furnidata_xml/updated_furni.xml",
"use.sso.ticket" : "1", 
"sso.ticket" : "{sso}", 
"processlog.enabled" : "0",
"client.starting" : "Olá {username}, {hotelName} esta carregando...", 
"client.starting.revolving" : "Quando você menos esperar...terminaremos de carregar.../Carregando mensagem divertida! Por favor espere./Você quer batatas fritas para acompanhar?/Siga o pato amarelo./O tempo é apenas uma ilusão./Já chegamos?!/Eu gosto da sua camiseta./Olhe para um lado. Olhe para o outro. Pisque duas vezes. Pronto!/Não é você, sou eu./Shhh! Estou tentando pensar aqui./Carregando o universo de pixels.",				"flash.client.url" : BaseUrl, 
"flash.client.origin" : "popup" 
};
var params =
{
"base" : BaseUrl + "/",
"allowScriptAccess" : "always",
"menu" : "false"
};
swfobject.embedSWF(BaseUrl + "/habbustoficial1.swf", "client", "100%", "100%", "10.0.0", "http://hebbust.com.br/swf/gordon/HABBUST/expressInstall.swf", flashvars, params, null);
</script>
    </head>

 
    <body>
    
        <div id="client"></div>
    </body>
</html>