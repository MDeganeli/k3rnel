<?php
	define("IN_INDEX", 1);
require_once "global.php";
include("../app/class.core.php");
ini_set("default_charset", "utf-8");


if (isset($_POST['daremblema'])) {
$nomedoemb = $_POST['nomedoemb'];
$descdoemb = $_POST['descdoemb'];
$nomedoemb2 = $_POST['nomedoemb2'];
$descdoemb2 = $_POST['descdoemb2'];

if($check==0){
echo("<center><div style='background-color:#EAF8E7; border:1px solid #70CD74;'>Emblema Adicionado com sucesso! ( Limpe o cache para visualizar )</div>.</center>");
$open = fopen("swf/gamedata/external_flash_texts/text_updated.txt","a");

$quebra = chr(13).chr(10);

fwrite($open,"badge_name_$nomedoemb=") and fwrite($open,"$nomedoemb2".$quebra);

fwrite($open,"badge_desc_$nomedoemb=") and fwrite($open,"$descdoemb2".chr(13).chr(10));

fclose($open);
}else{
echo("<div style='background-color:#EAF8E7; border:1px solid #70CD74;'>Nome e DescriÃ§Ã£o adicionados! ( Limpe o cache para visualizar )</div>");
$open = fopen("swf/gamedata/external_flash_texts/text_updated.txt","a");//pode ver os parÃ¢metros do fopen no php.net

$quebra = chr(13).chr(10);

fwrite($open,"badge_name_$nomedoemb=") and fwrite($open,"$nomedoemb2".$quebra);

fwrite($open,"badge_desc_$nomedoemb=") and fwrite($open,"$descdoemb2".chr(13).chr(10));

fclose($open);

}
}


if(isset($_FILES['arquivo']['name']) && $_FILES["arquivo"]["error"] == 0)
{

	$arquivo_tmp = $_FILES['arquivo']['tmp_name'];
	$nome = $_FILES['arquivo']['name'];



	$extensao = strrchr($nome, '.');


	$extensao = strtolower($extensao);


	if(strstr('.gif', $extensao))
	{

		$novoNome = $nomedoemb . $extensao;


		$destino = 'swf/c_images/album1584/' . $novoNome;


		if( @move_uploaded_file( $arquivo_tmp, $destino  ))
		{
			echo "<center>Link para o Emblema: <strong> swf/c_images/album1584/$nomedoemb.gif</strong><br /></center>";
			echo "<center><img src=\"" . $destino . "\" /></center>";
		}
		else
			echo "Erro ao Enviar o emblema. Aparentemente você não tem permissão de escrita.<br />";
	}
	else
		echo "Você poderá enviar apenas imagens .gif\"<br />";
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="https://www.facebook.com/2008/fbml">
  <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="LucasGomes">
	<script type='text/javascript' src='/app/tpl/skins/Habbo/jquery/jquery.js'></script>
	<title>{hotelName} - Emblema</title>
<?php  include_once("includes/styles.php"); ?>
</head>
	<body>
	<?php  include_once("includes/menu.php"); ?>
  <form method="post" enctype="multipart/form-data">

<div class="col-md-7">
		<div style="width:700px; margin-left:300px;" class="panel panel-primary">
			<div class="panel-heading" style="background-color:orange;">
          		<h3 class="panel-title">Adicionar emblema <i class="glyphicon glyphicon-star-empty" style="margin-top:1px;float:right"></i></h3>
      		</div>
			<div style="margin-left:220px;"><br>
<b>Apenas jornalistas tem acesso à essa página.</b><br><br>
<?php if($_SESSION['user']['rank'] > 6){ ?>
<strong>Codigo do emblema:</strong>
<br><input name="nomedoemb" type="text" placeholder="Exemplo: NV1" required />
<br><br><br>
<strong>Nome do emblema:</strong>
<br><input name="nomedoemb2" type="text"  placeholder="Título do Emblema" required />
<br><br>
<strong>Descrição do emblema:</strong>
<br><input name="descdoemb2" type="text"  placeholder="Descriçao do Emblema" required />
<br><br><br>
       <input name="arquivo" type="file" required />
	   <br>(Selecione apenas imagens .gif)
	   <br><b>OBS</b>: Nome da imagem precisa ser o mesmo do código.<br><br>
       <input name="daremblema" type="submit" value="Enviar Emblema" /><br><br>
	   </div><?php } ?>
</form>
</div>
</div>
</div>
</body>
</html>