<?php
    define("IN_INDEX", 1);
require_once "global.php";
include("../app/class.users.php");

$username = $_REQUEST["user"];
$userid = $_REQUEST["id"];

// User Info \\
$userinfo = mysql_query("SELECT * FROM users WHERE username='$username' or id='$userid'");
$get2 = mysql_fetch_assoc($userinfo);

if ($get2) {
}
else {
header("Location: /error");
}

$user = $get2['username'];
$id = $get2['id'];
$looks = $get2['look'];
$email = $get2['mail'];
$rank = $get2['rank'];
$motto = $get2['motto'];
$credits = $get2['credits'];
$pixels = $get2['activity_points'];
$pvip = $get2['diamonds'];
$online = $get2['online'];
$created = $get2['account_created'];
$lonline = $get2['last_online'];
$youtube = $get2['youtube'];

$pageid = "2";
include("includes/cabeca.php");
include("includes/menusite.php");
?>
<!-- Seção do Conteúdo -->
<body>
		<div class="container">
			
			<div class="col-xs-12 col-md-7" style="margin-right: 15px;">
	<div class="row">
		<div class="jumbotron jumbo front">				
			<div class="col-xs-2 col-md-2">
				<div style="margin-top: 19px;margin-left: 60px;height: 106px;width: 65px;background-image: url(' http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $looks; ?>&size=b&direction=2&head_direction=3&gesture=sml&frame=3&action=sit&img_format=png ');"></div>
			</div>
			<div class="col-xs-6 col-sm-7" style="float:right;">
				<div class="panel panel-primary">
					<div class="panel-body text-center">
						&Uacute;lt. Visita: <b> <?php echo gmdate("d/m/Y", $lonline); ?> </b>
						<hr style="border-top: 1px dashed #CACACA;">
						Criado desde: <b> <?php echo gmdate("d/m/Y", $created); ?> </b>
					</div>
				</div>
			</div>
		</div>						
	</div>
	<div class="row">
		<div class="col-xs-12 col-sm-5" style="margin-top: 30px;margin-right: 10px;">
			<div class="row">
				<div class="panel panel-primary">
					<div class="panel-body">
						<div class="grid_16">
							<div class="module-header colorBeige">
								<i class="fa fa-star-o fa-lg" style="margin-top: 5px;float:right"></i> Meus Emblemas
							</div>
						</div>
						<div id="contentBox" class="activity borderBeige">
							<?php

$getmybadges = mysql_query("SELECT * FROM users_badges WHERE user_id='$id'");

while($rowing = mysql_fetch_assoc($getmybadges)){
$badge = $rowing['badge_id'];
                                    echo "&nbsp;&nbsp;<img id='emblemas' src='/swf/c_images/album1584/".$badge.".gif'>&nbsp;&nbsp;";

}
?>
							</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6" style="margin-top: 30px;">
			<div class="row">
				<div class="panel panel-primary">
					<div class="panel-body">
						<div class="grid_16">
							<div class="module-header colorPurple">
								<i class="fa fa-archive fa-lg" style="margin-top: 5px;float:right"></i> Meus Quartos
							</div>
						</div>
						<div class="list-group" style="border-top: 2px solid #685D9F;">
														<div class="list-group-item" style="border-bottom-width: 0;border-left-width: 0;border-right-width: 0;">
								 <?php 
                               

							   
                                $nome = mysql_query("SELECT * FROM users WHERE id ='$id'");
                                while($pegarnome = mysql_fetch_array($nome)){
                                $capirototafudidocomigo = $pegarnome['id'];  
                                   
                                    $h = mysql_query("SELECT * FROM rooms_data WHERE owner ='$id' LIMIT 5");
                               
                                    while($g = mysql_fetch_array($h)){
                                        $codQuarto = $g['caption'];
                                        $useron = $g['users_now'];
                                       
                                        if($useron == 0){
                                            $useron = 'O quarto est&aacute; vazio';
                                        }else if($useron > 0 && $useron < 10){
                                            $useron .= " <font style='color:green;'>Usu&aacute;rios no quarto</font>";
                                        }
                                      
                                        echo '<div class="list-group-item">';
										 	
                                      
                                            echo '<img src="{url}/content/skin/Gold/assets/img/quartos.gif"/>';
										
												
                                                    echo '<span style="position: absolute;margin-left: 10px;margin-top: 5px;">';
												
                                                        echo "".$codQuarto."";
														
														
                                                    echo "</span>";
													
                                                    echo '<span style="position: absolute;margin-left: 10px;margin-top: 22px;">';
													
                                                        echo "".$useron."";
														
                                                    echo "</span>";
													
												
												
                                        echo "</div>";
										
                                    }
                                   
                                }
								
                        ?>
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="col-xs-12 col-sm-4">
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-body">
				<div class="grid_16" style="border-bottom: 2px solid #93c54b;">
					<div class="module-header colorGreen">
						<i class="fa fa-asterisk" style="margin-top: 5px;float: right;"></i> Minhas Informa&ccedil;&otilde;es
					</div>
				</div>
			</div>
			<div id="box">
				<table class="prof">
					<tr><td><span class="glyphicon glyphicon-user"></span></td>
						<td width="100%">ID <b><?php echo $id; ?></b></td></tr>
						<tr><td><img src="{url}/content/skin/Gold/assets/img/coins.png"></td>
							<td><b><?php echo $credits; ?></b> Moedas</td></tr>
							<tr><td><img src="{url}/content/skin/Gold/assets/img/duckets.png"></td>
								<td><b><?php echo $pixels; ?></b> Duckets(s)</td></tr>
									<tr><td><img src="{url}/content/skin/Gold/assets/img/pipocas.gif"></td>
										<td><b><?php echo $pvip; ?></b>  Pipoca(s)</td></tr>
										<tr><td><span class="glyphicon glyphicon-pencil"></span></td>
											<td><?php echo $motto; ?></td></tr>
										</table>
									</div>
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-4">
							<div class="row">
								<div class="panel panel-primary" style="height: 293px;margin-right: 10px;">
									<div class="panel-body">
										<div class="grid_16" style="border-bottom: 2px solid #D9534F;">
											<div class="module-header colorRed">
												<i class="fa fa-youtube-play fa-lg" style="float: right;"></i> Meu Vídeo
											</div>
										</div>
									</div>
									<iframe width="100%" height="250" src="https://www.youtube.com/embed/<?php echo $youtube; ?>" frameborder="0" allowfullscreen></iframe>

								</div>
							</div>
						</div>
 <?php include("includes/footer.php");?>