<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="Hart&Killua">
	<title>{hotelName} - Criar conta</title>

<?php  include_once("includes/styles.php"); ?>
</head>
<?php  include_once("includes/menuindex.php"); ?>
<body>

	<div class="jumbotron container-jumbo">
	
	<div class="container">
		<div class="row">
			<div class="col-sm-2">
				<div class="hotel-register"><img src="{url}/content/skin/Gold/assets/img/hotel.png" style="width:100%;visibility:hidden;"></div>
			</div>

			<div class="col-sm-7 text-center content-registro">
				<div class="form-group">
					<div class="col-sm-offset-4 col-sm-8">
						<span style="font-size:35px">Bem-Vindo ao Hebbust</span><br/>O melhor Hotel do Brasil!<br><br>
					</div>
				</div>
			</div>
		</div>			
	</div>
	<?php if(isset($template->form->error)) { echo '<div class="alert alert-danger"><center><span class="glyphicon glyphicon-info-sign"></span> '.$template->form->error.'</center></div>'; } ?>
</div>

<div class="container">
	<div class="col-sm-offset-1 col-xs-12 col-sm-6" style="margin-right: 15px;">
		<div class="row">
			<div class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16">
						<div class="module-header colorPink">
							<i class="fa fa-user fa-lg" style="margin-top: 4px;float:right"></i> Suas Informações
						</div>
					</div>
					<div id="contentBox" class="activity borderPink">
						<form method="post" action="{url}/register" style="margin-bottom: 0;">
							<div class="input-group">
								<span class="input-group-addon" id="username"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>
								<input type="text" class="form-control" name="reg_username" value="" placeholder="Nome de Usuário" aria-describedby="username" autofocus required>
							</div>
							<br>
							<div class="input-group">
								<span class="input-group-addon" id="email"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span></span>
								<input type="text" class="form-control" name="reg_email" value="" placeholder="Email" aria-describedby="email" autofocus required>
							</div>
							<br>
							<div class="input-group">
								<span class="input-group-addon" id="password"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span></span>
								<input type="password" class="form-control" name="reg_password" value="" placeholder="Senha" aria-describedby="password" autofocus required>
							</div>
							<br>
							<div class="input-group">
								<span class="input-group-addon" id="password-repeat"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span></span>
								<input type="password" class="form-control" name="reg_rep_password" placeholder="Repita a Senha" aria-describedby="password-repeat" autofocus required>
							</div>
							<br>
							<div class="btn-group" style="float:right">
								<button type="submit" name="register" class="btn btn-success">Criar a Conta!</button>
							</div>
						</form>
						<a href="{url}" type="button" class="btn btn-danger">Já tenho Conta!</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="col-xs-12 col-sm-3">
		<div class="row">
			<div class="panel panel-primary">
				<div class="panel-body">
					<div class="grid_16">
						<div class="module-header colorBlue">
							<i class="fa fa-lock fa-lg" style="margin-top: 4px;float:right"></i> Dicas de Segurança
						</div>
					</div>
					<div id="contentBox" class="activity borderBlue">
						<img src="{url}/content/skin/Gold/assets/img/lock.png" style="float:right;">
						<b>1ª -</b> Nunca passe sua senha para nenhum usuários;<br><b>2ª -</b> Evite divulgar informações pessoais;<br><b>3ª -</b> Nenhum Staff irá pedir sua senha para te ajudar;<br><b>4ª -</b> Nunca passe seu email para ninguém;<br><b>5ª -</b> Ao sair de qualquer computador, certifique-se que você está desconectado do hotel.
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php  include_once("includes/footer.php"); ?>