<?php
$pagename = Perfil;
$pageid = "2";
include("includes/cabeca.php");
include("includes/menusite.php");

    define("IN_INDEX", 1);
require_once "global.php";
include("../app/class.users.php");

$username = $_REQUEST["user"];
$userid = $_REQUEST["id"];

// User Info \\
$userinfo = mysql_query("SELECT * FROM users WHERE username='$username' or id='$userid'");
$get2 = mysql_fetch_assoc($userinfo);

$user = $get2['username'];
$id = $get2['id'];
$looks = $get2['look'];
$email = $get2['mail'];
$rank = $get2['rank'];
$motto = $get2['motto'];
$credits = $get2['credits'];
$pixels = $get2['activity_points'];
$pvip = $get2['seasonal_currency'];
$online = $get2['online'];
$created = $get2['account_created'];
$lonline = $get2['last_online'];
$youtube = $get2['youtube'];

?>
<body>
		<div class="container">
<?php
$e = mysql_query("SELECT * FROM users WHERE username='$username' or id='$userid'");
while($f = mysql_fetch_array($e)){

if ($get2) {
}
else {
header("Location: /error");
}
?>
			<div class="col-xs-12 col-md-7" style="margin-right: 15px;">
	<div class="row">
		<div class="jumbotron jumbo front">				
			<div class="col-xs-2 col-md-2">
				<div style="margin-top: 19px;margin-left: 60px;height: 106px;width: 65px;background-image: url('http://avatar-retro.com/habbo-imaging/avatarimage?figure=<?php echo $looks; ?>&size=b&direction=2&head_direction=3&gesture=sml&frame=3&action=sit&img_format=png');"></div>
			</div>
			<div class="col-xs-6 col-sm-7" style="float:right;">
				<div class="panel panel-primary">
					<div class="panel-body text-center">
						Últ. Visita: <b>8 horas e 29 minutos atrás</b>
						<hr style="border-top: 1px dashed #CACACA;">
						Criado desde: <b>1 mes atrás</b>
					</div>
				</div>
			</div>
		</div>						
	</div>
	<?php } ?>
	<div class="row">
		<div class="col-xs-12 col-sm-5" style="margin-top: 30px;margin-right: 10px;">
			<div class="row">
				<div class="panel panel-primary">
					<div class="panel-body">
						<div class="grid_16">
							<div class="module-header colorBeige">
								<i class="fa fa-star-o fa-lg" style="margin-top: 5px;float:right"></i> Meus Emblemas
							</div>
						</div>
						<div id="contentBox" class="activity borderBeige">
							<?php
                           
                           
                                $idusuario = $_SESSION['user']['id'];
                                $e = mysql_query("SELECT * FROM users_badges WHERE user_id ='".$idusuario."'");
                                while($f = mysql_fetch_array($e)){
                                    $codEmblema = $f['badge_id'];
                                    echo "<img id='emblemas' src='/swf/c_images/album1584/".$codEmblema.".gif'>";
                                   
                                }
           
                        ?>					
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6" style="margin-top: 30px;">
			<div class="row">
				<div class="panel panel-primary">
					<div class="panel-body">
						<div class="grid_16">
							<div class="module-header colorPurple">
								<i class="fa fa-archive fa-lg" style="margin-top: 5px;float:right"></i> Meus Quartos
							</div>
						</div>
						<div class="list-group" style="border-top: 2px solid #685D9F;">
							<?php 
							   $idusuari = $_SESSION['user']['id'];
                                $nome = mysql_query("SELECT * FROM users WHERE id ='".$idusuari."'");
                                while($pegarnome = mysql_fetch_array($nome)){
                                $capirototafudidocomigo = $pegarnome['username'];  
                                   
                                    $h = mysql_query("SELECT * FROM rooms_data WHERE owner ='".$capirototafudidocomigo."'");
                               
                                    while($g = mysql_fetch_array($h)){
                                        $codQuarto = $g['caption'];
                                        $useron = $g['users_now'];
                                       
                                        if($useron == 0){
                                            $useron = 'O quarto est&aacute; vazio';
                                        }else if($useron > 0 && $useron < 10){
                                            $useron .= " <font style='color:green;'>Usu&aacute;rios no quarto</font>";
                                        }
                                      
                                        echo "<div id='cascudo'>";
										 	
                                      
                                            echo "<table id='quartos'>";
										
                                                echo "<tr id='tr'><a href='#'>";
												
                                                    echo "<td class='td'>";
													 echo "<img src='{url}/content/skin/Gold/assets/img/quartos.gif'>";
												
                                                        echo "<font>".$codQuarto."</font>";
														
														
                                                    echo "</td>";
													
                                                    echo "<td class='td' style='text-align:right;'>";
													
                                                        echo "<font>".$useron."</font>";
														
                                                    echo "</td>";
													
                                                echo "</tr></a>";
												
                                                echo "</table>";
												
                                        echo "</div>";
										
                                    }
                                   
                                }
								
                        ?>
													</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="col-xs-12 col-sm-4">
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-body">
				<div class="grid_16" style="border-bottom: 2px solid #93c54b;">
					<div class="module-header colorGreen">
						<i class="fa fa-asterisk" style="margin-top: 5px;float: right;"></i> Minhas Informações
					</div>
				</div>
			</div>
			<div id="box">
				<table class="prof">
					<tr><td><span class="glyphicon glyphicon-user"></span></td>
						<td width="100%">ID <b>503427</b></td></tr>
						<tr><td><img src="http://hebbohotel.in/content/skin/Umbar/assets/img/icons/coins.png"></td>
							<td><b>5000150</b> Moedas</td></tr>
							<tr><td><img src="http://hebbohotel.in/content/skin/Umbar/assets/img/icons/rosquinha.png"></td>
								<td><b>1</b> Rosquinha(s)</td></tr>
								<tr><td><img src="http://hebbohotel.in/content/skin/Umbar/assets/img/icons/event.png"></td>
									<td><b>0</b> Ponto(s) de Evento(s)</td></tr>
									<tr><td><img src="http://hebbohotel.in/content/skin/Umbar/assets/img/icons/diamonds.png"></td>
										<td><b>1</b>  Diamante(s)</td></tr>
										<tr><td><span class="glyphicon glyphicon-pencil"></span></td>
											<td>Sou novato! :)</td></tr>
										</table>
									</div>
								</div>
							</div>
						</div>

						<div class="col-xs-12 col-sm-4">
							<div class="row">
								<div class="panel panel-primary" style="height: 293px;margin-right: 10px;">
									<div class="panel-body">
										<div class="grid_16" style="border-bottom: 2px solid #D9534F;">
											<div class="module-header colorRed">
												<i class="fa fa-youtube-play fa-lg" style="float: right;"></i> Meu Vídeo
											</div>
										</div>
									</div>
									<iframe width="100%" height="250" src="https://www.youtube.com/embed/?rel=0&amp;controls=1" frameborder="0" allowfullscreen></iframe>

								</div>
							</div>
						</div>
						
			
		</div>
<?php  include_once("includes/footer.php"); ?>