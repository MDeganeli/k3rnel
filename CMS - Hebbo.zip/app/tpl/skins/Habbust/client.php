<!-- ANUNCIO -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
var time = 30;
var timerun = true;
 
function closeTheBanner1() {
    $(".roomenterad-habblet-container1").animate({
                top: -$(".roomenterad-habblet-container1").height() + "px"
        }, 2000);
        timerun = false
}
 
setInterval(function () {
    if (timerun) {
        $(".roomenterad-closing1").text("Fechando em " + time +" segundos");
        time--;
        if (time < 0) {
                        closeTheBanner1();
        }
    }
}, 2000);
 
setInterval(function () {
    var htmlz = $(".roomenterad-habblet-thead1").html();
    $(".roomenterad-habblet-thead1").text("");
    $(".roomenterad-habblet-container1").animate({
                top: "0px"
        }, 2000);
    $(".roomenterad-habblet-thead1").html(htmlz);
    time = 30;
    timerun = true
}, 300000);
</script>
</head>
<div class="roomenterad-habblet-container1" style="display: inline-block; left: 50%; margin-left: -370px; margin-top: -30px; position: fixed; height: 195px; width: 740px; background-image: url(http://i.imgur.com/H2CeyfP.png); background-repeat: no-repeat no-repeat; z-index: 99999;">
<div style="position: absolute; right: 22px; top: 76px; color: #ffffff; font-weight: bold; font-size: 10px; font-family: Verdana, sans-serif;">Fechar agora</div>
<div style="position: absolute; left: 6px; top: 76px; color: rgb(255, 255, 255); font-size: 10px; font-family: Verdana, sans-serif; visibility: visible;" class="roomenterad-closing1">Fechando em 30 segundos</div>
<div style="position: absolute; right: 9px; top: 75px;"><img onclick="closeTheBanner1();" src="http://i.imgur.com/VuLhUw2.png"></div>
<div style="position: absolute; left: 6px; top: 91px" class="roomenterad-habblet-thead1">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Lucases -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-3716724879003548"
     data-ad-slot="7375081511"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
</div>
<!-- ANUNCIO -->
<?php 
		// Include Header
		include "bans/checkipban.php"; 
		include "bans/checktheban.php"; 
	?>
<!--
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Habbust - Jogar</title>

<link rel="stylesheet" href="http://hebblon.com/app/tpl/skins/Habbo/style/client.css" type="text/css">

<script type="text/javascript" src="http://hebblon.com/app/tpl/skins/Habbo/js/swfobject.js"></script>
<script type="text/javascript">
var BaseUrl = "http://painel.hebblon.com/swf/gordon/RELEASE63-277546541/";
var flashvars =
{ 
"client.allow.cross.domain" : "1", 
"client.notify.cross.domain" : "0", 
"connection.info.host" : "179.24.267.8",
"connection.info.port" : "30000", 
"site.url" : "http://hebblon.com", 
"url.prefix" : "http://hebblon.com", 
"client.reload.url" : "http://hebblon.com/client", 
"client.fatal.error.url" : "http://hebblon.com/disconnected",
"logout.url" : "http://hebblon.com/disconnected", 
"logout.disconnect.url" : "http://hebblon.com/disconnected", 
"client.connection.failed.url" : "http://hebblon.com/disconnected", 
"external.variables.txt" : "http://painel.hebblon.com/swf/gamedata/external_variables/variabes.txt", 
"external.texts.txt" : "http://painel.hebblon.com/swf/gamedata/external_flash_texts/textos.txt",  
"productdata.load.url" : "http://painel.hebblon.com/swf/gamedata/productdata/product.txt", 
"furnidata.load.url" : "http://painel.hebblon.com/swf/gamedata/furnidata_xml/furni.xml",
"use.sso.ticket" : "1", 
"sso.ticket" : "{sso}", 
"processlog.enabled" : "0",
"client.starting" : "Olá {username}, {hotelName} esta carregando...", 
"client.starting.revolving" : "Quando você menos esperar...terminaremos de carregar.../Carregando mensagem divertida! Por favor espere./Você quer batatas fritas para acompanhar?/Siga o pato amarelo./O tempo é apenas uma ilusão./Já chegamos?!/Eu gosto da sua camiseta./Olhe para um lado. Olhe para o outro. Pisque duas vezes. Pronto!/Não é você, sou eu./Shhh! Estou tentando pensar aqui./Carregando o universo de pixels.",				"flash.client.url" : BaseUrl, 
"flash.client.origin" : "popup" 
};
var params =
{
"base" : BaseUrl + "/",
"allowScriptAccess" : "always",
"menu" : "false"
};
swfobject.embedSWF(BaseUrl + "/Habbo.swf", "client", "100%", "100%", "10.0.0", "http://painel.hebblon.com/swf/gordon/RELEASE63-277546541/expressInstall.swf", flashvars, params, null);
</script>
    </head>

 
    <body>
    
        <div id="client"></div>
    </body>
</html>
//-->
<link rel="shortcut icon" type="img/png" href="http://habbust.net/content/skin/Gold/assets/images/icons/gold.png">
<script>
<!--
document.write(unescape("%3Chtml%3E%0A%3Chead%3E%0A%3Ctitle%3EHabbust:%20Jogar%3C/title%3E%0A%3Cstyle%20type%3D%22text/css%22%3E%0A%20%20%20%20html%2C%20body%20%7B%20%0A%20%20%20%20%20%20margin%3A0%3B%20%0A%20%20%20%20%20%20padding%3A0%3B%20%0A%20%20%20%20%20%20height%3A100%25%3B%20%0A%20%20%20%20%20%20width%3A%20100%25%3B%20%0A%20%20%20%20%20%20overflow%3A%20hidden%0A%20%20%20%7D%0A%20%20%20body%20%7B%0A%20%20%20%20%20%20font-family%3A%20arial%3B%0A%20%20%20%20%20%20font-size%3A12px%3B%0A%20%20%20%20%20%20color%3A%236fa5fd%3B%0A%20%20%20%20%20%20background-color%3A%20%23444444%20%21important%3B%0A%20%20%20%20%20%20/*background-image%3A%20url%28%27/imagenes/bg.png%27%29%3B*/%0A%20%20%20%7D%0A%20%20%20%20iframe%20%7B%20display%3Ablock%3B%20width%3A100%25%3B%20height%3A100%25%3B%20border%3Anone%3B%20margin%3A0%3B%20padding%3A0%3B%20%7D%20%0A%20%20%20%3C/style%3E%0A%3Cscript%20src%3D%22http%3A//code.jquery.com/jquery-1.4.3.min.js%22%3E%3C/script%3E%20%0A%3Cscript%3E%0A%24%28document%29.ready%28function%28%29%7B%0A%0A%20%20%20//%20Dialog%20%20%20%20%20%20%20%20%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%24%28%27%23dialogo%27%29.dialog%28%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20autoOpen%3A%20true%2C%20%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20width%3A%20600%2C%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20buttons%3A%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%22Empezar%20a%20jugar%22%3A%20function%28%29%20%7B%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%24%28this%29.dialog%28%22close%22%29%3B%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%24%28%22%23backgroundPopup%22%29.fadeOut%28%22slow%22%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%7D%2C%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%20%20%20%20%20%20%7D%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%24%28%22%23backgroundPopup%22%29.fadeIn%28%22slow%22%29%3B%0A%0A%7D%29%3B%0A%3C/script%3E%0A%3Cdiv%20style%3D%22float%3Aleft%3B%20width%3A%20100%25%3B%20height%3A100%25%3B%20z-index%3A%202%22%3E%0A%20%20%20%3Cdiv%20id%3D%22cliente%22%20style%3D%22position%3Arelative%3B%20z-index%3A%203%22%3E%0A%20%20%20%20%20%20%3Ciframe%20border%3D%220%22%20frameBorder%3D%22NO%22%20width%3D%22100%25%22%20height%3D%22100%25%22%20SCROLLING%3D%22NO%22%20marginHeight%3D%220px%22%20marginwidth%220px%22%20src%3D%22/i%22%3E%3C/iframe%3E%0A%20%20%20%3C/div%3E%0A%3C/div%3E%0A%3C/html%3E"));
//-->
</script>