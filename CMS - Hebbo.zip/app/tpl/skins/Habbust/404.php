<?php
$pagename = ERRO;
$pageid = "1";
include("includes/cabeca.php");
include("includes/menusite.php");
?>
<body>
		<div class="container">
			
			<div class="col-md-3">
  <div class="panel panel-primary">
    <div class="panel-body">
      <div class="grid_16">
        <div class="module-header colorRed">
          <i class="fa fa-question fa-lg" style="margin-top: 4px;float:right"></i> Página não Encontrada
        </div>
      </div>
    <div id="contentBox" class="activity borderRed">
      Você tentou acessar uma página na qual não existe em nosso sistema ou você não tem as permissões necessárias para poder acessar! Por favor, veja algumas dicas ao lado para ver se você consegue acessar a página desejada!
    </div>
  </div>
</div>
</div>

<div class="col-md-7">
  <div class="panel panel-primary">
    <div class="panel-body">
      <div class="grid_16">
        <div class="module-header colorRed">
          <i class="fa fa-question fa-lg" style="margin-top: 4px;float:right"></i> Dicas de Acesso
        </div>
      </div>
    <div id="contentBox" class="activity borderRed">
      <ul><li>Tente analisar direitinho a sua URL para ver se não esta faltando algo ou se tem algum caractere a mais;</li><li>Você está logado? Se não estiver, algumas páginas contidas em nosso Site só podem ser vistas se você estiver logado em uma conta;</li><li>O problema insiste bastante em persistir? Contate algum Staff em nossa página do <strong><a href="http://facebook.com/HebbustOficial" style="color: #886640;" target="_blank">Facebook</a></strong>. Ficaremos felizes em ajudar você;</li></ul>
    </div>
  </div>
</div>
</div>
<?php  include_once("includes/footer.php"); ?>