<?php
require_once('config.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>FooaPanel - Login</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
<!-- FIM DO CSS DO BOOTSTRAP -->
<?php  include_once("fooa/menu.php"); ?>
<!-- INICIO DO WARNING -->

<!-- FIM DO WARNING -->
<body>
<div id="conteudo">

<div class="panel panel-success">
  <div class="panel-heading">
    <h3 class="panel-title">Login</h3>
  </div>
  <div class="panel-body">
  <center>
        <form method="post" action="logar.php">
        <strong>Usuário:</strong>&nbsp;<input type="text" name="usuario"><br /><br />
        <strong>Senha:</strong>&nbsp;<input type="password" name="senha"><br /><br />
        <input type="submit" value="Logar" class="btn btn-primary">
        </form>
        </br>
        </center>
        <div class="alert alert-dismissible alert-warning">
  <button type="button" class="close" data-dismiss="alert">Ok</button>
  <h4>Opa!</h4>
  <p>O painel ainda está na sua primeira versão então se achar algum bug: <a href="#" class="alert-link">Contato</a>.</p>
</div>
  </div>
</div>


  


</div>
<!-- JS DO BOOTSTRAP -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- FIM DO JS DO BOOTSTRAP -->
</body>

</html>