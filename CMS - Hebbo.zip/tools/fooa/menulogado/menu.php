<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="logout.php"><strong>Sair</strong></a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Inicio<span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="emblemas.php">Emblemas<span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="daremblema.php">Informações<span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="perfil.php">Perfil<span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="cms.php"><strong>CMS</strong><span class="sr-only">(current)</span></a></li>
    </div>
  </div>

</nav>