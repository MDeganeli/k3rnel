<?php
require_once('config.php');
?>
<?php
session_start();
if(!isset($_SESSION['usuario']) || !isset($_SESSION['senha'])) {
    header("location: login.php");
    exit;
}
?>
<html>
<meta charset="utf-8">
<head>
<title>KilluaPainel - Upload de Emblema</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
<!-- FIM DO CSS DO BOOTSTRAP -->
<?php  include_once("fooa/menulogado/menu.php"); ?>
<body>


<div class="panel panel-default">
  <div class="panel-body">
    <div class="jumbotron">
  <h1>Funções Disponivel na CMS!</h1>
  </br>
  </br>
  <p><a href="news.php" class="btn btn-primary btn-lg">Adicionar Notícia</a></p>
  </div>
  </div>
</div>



</body>

</html>