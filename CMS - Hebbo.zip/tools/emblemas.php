<?php
require_once('config.php');
?>
<?php
session_start();
if(!isset($_SESSION['usuario']) || !isset($_SESSION['senha'])) {
    header("location: login.php");
    exit;
}
?>
<html>
<meta charset="utf-8">
<head>
<title>FooaPanel - Upload de Emblema</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
<!-- FIM DO CSS DO BOOTSTRAP -->
<?php  include_once("fooa/menulogado/menu.php"); ?>
<body>

<?php
require_once('config.php');
?>
<?php
session_start();
if(!isset($_SESSION['usuario']) || !isset($_SESSION['senha'])) {
    header("location: login.php");
    exit;
}
?>
<html>
<meta charset="utf-8">
<head>
<title>FooaPanel - Upload de Emblema</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
<!-- FIM DO CSS DO BOOTSTRAP -->
<?php  include_once("fooa/menulogado/menu.php"); ?>
<body>



<div class="panel panel-default">
  <div class="panel-body">

<center>
<form method="post" enctype="multipart/form-data" action="emblemas.php">

<h1>Adicionar Emblemas</h1>
<strong>Codigo do Emblema</strong>
<br><input name="nomedoemb" type="text" placeholder="EXEMPLO: NV1" required />
<br><br><br>
<strong>Nome do emblema</strong>
<br><input name="nomedoemb2" type="text"  placeholder="TÍTULO DO EMBLEMA" required />
<br><br>
<strong>Descrição do Emblema</strong>
<br><input name="descdoemb2" type="text"  placeholder="DESCRIÇÃO DO EMBLEMA" required />
<br><br><br>
       <input name="arquivo" type="file" required />
	   <br><br>(Selecione a imagem do emblema em formato .gif corretamente para não bugar)<br><br>
       <input name="daremblema" type="submit" value="Enviar Emblema" />
</form>
<br><br><br>
</form>
<?php

if (isset($_POST['daremblema'])) {
$nomedoemb = $_POST['nomedoemb'];
$descdoemb = $_POST['descdoemb'];
$nomedoemb2 = $_POST['nomedoemb2'];
$descdoemb2 = $_POST['descdoemb2'];

if($check==0){
echo("<div style='background-color:#EAF8E7; border:1px solid #70CD74;'>Emblema Adicionado com sucesso! ( Limpe o cache para visualizar )</div>.");
$open = fopen("./CAMINHO DO SEU texts Exemplo: ./swf/external_flash_texts/1.txt)","a");

$quebra = chr(13).chr(10);

fwrite($open,"badge_name_$nomedoemb=") and fwrite($open,"$nomedoemb2".$quebra);
 
fwrite($open,"badge_desc_$nomedoemb=") and fwrite($open,"$descdoemb2".chr(13).chr(10));
c
fclose($open);
}else{
echo("<div style='background-color:#EAF8E7; border:1px solid #70CD74;'>Nome e DescriÃ§Ã£o adicionados! ( Limpe o cache para visualizar )</div>");
$open = fopen("./swfv3/gamedata/external_flash_texts/145f3027561369d3b570dd686e0ae241436f8246.txt","a");//pode ver os parÃ¢metros do fopen no php.net

$quebra = chr(13).chr(10);

fwrite($open,"badge_name_$nomedoemb=") and fwrite($open,"$nomedoemb2".$quebra);

fwrite($open,"badge_desc_$nomedoemb=") and fwrite($open,"$descdoemb2".chr(13).chr(10));

fclose($open);

}
}


if(isset($_FILES['arquivo']['name']) && $_FILES["arquivo"]["error"] == 0)
{

	$arquivo_tmp = $_FILES['arquivo']['tmp_name'];
	$nome = $_FILES['arquivo']['name'];
	


	$extensao = strrchr($nome, '.');


	$extensao = strtolower($extensao);


	if(strstr('.gif', $extensao))
	{

		$novoNome = $nomedoemb . $extensao;
		

		$destino = './swf/c_images/album1584/' . $novoNome; 
		

		if( @move_uploaded_file( $arquivo_tmp, $destino  ))
		{
			echo "Link para o Emblema: <strong> http://linkdoseuhotel/swf/c_images/album1584/$nomedoemb.gif</strong><br />";
			echo "<img src=\"" . $destino . "\" />";
		}
		else
			echo "Erro ao Enviar o emblema. Aparentemente você não tem permissão de escrita.<br />";
	}
	else
		echo "Você poderá enviar apenas imagens .gif\"<br />";
}
else
{
	echo "Você não enviou nenhum arquivo!";
}

?>

</center>
  </div>
</div>



</body>

</html>



</body>

</html>