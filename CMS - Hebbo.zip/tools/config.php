<?php
session_start();
$host = "localhost";
$user = "root";
$pass = "";
$banco = "magic";

mysql_connect("$host", "$user", "$pass") or die("Erro na Conexão");
mysql_select_db("$banco") or die("Erro na conexão com o banco de dados");

# Painel

$painels = "Funcionando";
$versao = "1.0";
$criador = "Killua";
$missao = "www.Habbust.com.br - O Melhor";
$cinicial = "10000";
$dinicial = "5000";
$nhotel = "Habbust";





# Manutenção

$_CONFIG['hotel']['in_maint'] = false;
// True para Ativado \/ False para Desativado \\

# Avatar Inícial

$_CONFIG['hotel']['motto'] = 'www.Habbust.com.br - O Melhor';
$_CONFIG['hotel']['credits'] = 999999;
$_CONFIG['hotel']['pixels'] = 999999;
$_CONFIG['hotel']['figure'] = 'hr-3163-51.sh-3206-110.fa-1201-80.ch-3050-96-93.lg-3202-110-62.cp-3204-62.ca-1816-62.ea-3226-110.hd-180-1';

# CMS Release

$_CONFIG['hotel']['web_build'] = '63_1dc60c6d6ea6e089c6893ab4e0541ee0/2769';

# Configurações da Cliente

$_CONFIG['hotel']['external_vars'] = 'http://dominiotemp.in.net/gamedata/external_variables/1.txt';
$_CONFIG['hotel']['external_texts'] = 'http://dominiotemp.in.net/gamedata/external_flash_texts/55d43ac4381c3b38a1999a4b9269c135aca3eaab.txt';
$_CONFIG['hotel']['product_data'] = 'http://dominiotemp.in.net/gamedata/productdata/pswf.txt';
$_CONFIG['hotel']['furni_data'] = 'http://dominiotemp.in.net/gamedata/furnidata_xml/updated_furni.xml';
$_CONFIG['hotel']['swf_folder'] = 'http://dominiotemp.in.net/gordon/PRODUCTION-201506161211/';

# Tema

$_CONFIG['template']['style'] = 'Hab'; 
$_CONFIG['template']['theme'] = 'bust'; 

# API Votação

$_CONFIG['thehabbos']['username'] = '';
$_CONFIG['retro_top']['user'] = ''; 

# Captcha

$_CONFIG['recaptcha']['priv_key'] = '6LcZ58USAAAAABSV5px9XZlzvIPaBOGA6rQP2G43';
$_CONFIG['recaptcha']['pub_key'] = '6LcZ58USAAAAAAQ6kquItHl4JuTBWs-5cSKzh6DD';

# Redes Sociais

$_CONFIG['social']['twitter'] = ''; //Hotel's Twitter account
$_CONFIG['social']['facebook'] = ''; //Hotel's Facebook account
?>

