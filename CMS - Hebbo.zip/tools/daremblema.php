<?php
require_once('config.php');
?>
<?php
session_start();
if(!isset($_SESSION['usuario']) || !isset($_SESSION['senha'])) {
    header("location: login.php");
    exit;
}
?>
<html>
<meta charset="utf-8">
<head>
<title>FooaPanel - Upload de Emblema</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
<!-- FIM DO CSS DO BOOTSTRAP -->
<?php  include_once("fooa/menulogado/menu.php"); ?>
<body>
<div class="jumbotron">
  <h1>Informações do Servidor</h1>
  <p>O sistema está: <strong><?php echo "$painels"; ?></strong></p>
  <p>Versão: <strong><?php echo "$versao"; ?></strong></p>
  <p>Criador: <strong><?php echo "$fooa"; ?></strong></p>
  <p>A missão mais usada: <strong><?php echo "$missao"; ?></strong></p>
  <p>Créditos Inicial: <strong><?php echo "$cinicial"; ?></strong></p>
  <p>Ouro Inicial: <strong><?php echo "$dinicial"; ?></strong></p>
  <p>Nome do Hotel: <strong><?php echo "$nhotel"; ?></strong></p>
  <script type="text/javascript" src="http://www.skypeassets.com/i/scom/js/skype-uri.js"></script>
<div id="SkypeButton_Call_mac.burn1_1">
 <script type="text/javascript">
 Skype.ui({
 "name": "call",
 "element": "SkypeButton_Call_mac.burn1_1",
 "participants": ["mac.burn1"]
 });
 </script>
</div>,

  </div>

                                </body>
                                </html>