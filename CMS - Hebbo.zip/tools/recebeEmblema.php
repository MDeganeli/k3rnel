﻿
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Upload de Emblemas</title>
</head>

<body>
<?php

if (isset($_POST['daremblema'])) {
$nomedoemb = $_POST['nomedoemb'];
$descdoemb = $_POST['descdoemb'];
$nomedoemb2 = $_POST['nomedoemb2'];
$descdoemb2 = $_POST['descdoemb2'];

if($check==0){
echo("<div style='background-color:#EAF8E7; border:1px solid #70CD74;'>Emblema Adicionado com sucesso! ( Limpe o cache para visualizar )</div>.");
$open = fopen("./CAMINHO DO SEU texts Exemplo: ./swf/external_flash_texts/1.txt)","a");

$quebra = chr(13).chr(10);

fwrite($open,"badge_name_$nomedoemb=") and fwrite($open,"$nomedoemb2".$quebra);

fwrite($open,"badge_desc_$nomedoemb=") and fwrite($open,"$descdoemb2".chr(13).chr(10));

fclose($open);
}else{
echo("<div style='background-color:#EAF8E7; border:1px solid #70CD74;'>Nome e DescriÃ§Ã£o adicionados! ( Limpe o cache para visualizar )</div>");
$open = fopen("./CAMINHO DO SEU texts Exemplo: ./swf/external_flash_texts/1.txt","a");//pode ver os parÃ¢metros do fopen no php.net

$quebra = chr(13).chr(10);

fwrite($open,"badge_name_$nomedoemb=") and fwrite($open,"$nomedoemb2".$quebra);

fwrite($open,"badge_desc_$nomedoemb=") and fwrite($open,"$descdoemb2".chr(13).chr(10));

fclose($open);

}
}


if(isset($_FILES['arquivo']['name']) && $_FILES["arquivo"]["error"] == 0)
{

	$arquivo_tmp = $_FILES['arquivo']['tmp_name'];
	$nome = $_FILES['arquivo']['name'];
	


	$extensao = strrchr($nome, '.');


	$extensao = strtolower($extensao);


	if(strstr('.gif', $extensao))
	{

		$novoNome = $nomedoemb . $extensao;
		

		$destino = './swf/c_images/album1584/' . $novoNome; 
		

		if( @move_uploaded_file( $arquivo_tmp, $destino  ))
		{
			echo "Link para o Emblema: <strong> http://linkdoseuhotel/swf/c_images/album1584/$nomedoemb.gif</strong><br />";
			echo "<img src=\"" . $destino . "\" />";
		}
		else
			echo "Erro ao Enviar o emblema. Aparentemente você não tem permissão de escrita.<br />";
	}
	else
		echo "Você poderá enviar apenas imagens .gif\"<br />";
}
else
{
	echo "Você não enviou nenhum arquivo!";
}

?>
</body>
</html>
<?php } ?>