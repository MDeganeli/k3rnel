<?php
require_once('config.php');
?>
<?php
session_start();
if(!isset($_SESSION['usuario']) || !isset($_SESSION['senha'])) {
    header("location: login.php");
    exit;
}
?>
<html>
<meta charset="utf-8">
<head>
<title>FooaPanel - Upload de Emblema</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
  <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
<!-- FIM DO CSS DO BOOTSTRAP -->

<body>
<center>
<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Add News</h3>
							</div>
							<div class="module-body">

								<?php
								if($_SESSION['user']['rank'] >= 6){

								function secureStr($str) {
									return mysql_real_escape_string(stripslashes(htmlspecialchars($str)));
								}
								if(isset($_POST['news_create'])) {
									$title = secureStr($_POST['title']);
									$shortstory = secureStr($_POST['shortstory']);
									$longstory = secureStr($_POST['longstory']);
									$topstory = secureStr(mysql_real_escape_string($_POST['topstory']));
									
									if(empty($title)){
										echo '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">×</button><strong>Error:</strong> You have not entered a Title.</div>';
									}
									
									else if(empty($shortstory)){
										echo '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">×</button><strong>Error:</strong> You have not entered a Short Story.</div>';
									}
									
									else if(empty($longstory)){
										echo '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">×</button><strong>Error:</strong> You havent entered a Long Story.</div>';
									}
									
									else{
										$q = "INSERT INTO cms_news (title, shortstory, longstory, published, image, author) VALUES('{$title}','{$shortstory}','" . htmlspecialchars_decode($longstory) . "'," . time() . ",'{$topstory}','". $_SESSION['user']['username'] ."')";
										$q_nupdate = "INSERT INTO hk_logs (type, time, who_done) VALUES('News Article(" . $_POST['title'] .")','". time() ."','{$_SESSION['user']['username']}')";

										mysql_query($q) or die(mysql_error());
										mysql_query ($q_nupdate);
										echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">×</button><strong>Well done!</strong> News Article created.</div>';
									}
								}
								else if($_POST['topstory_view']){ ?>
									<p><center><img src="{url}/ase/yolo/<?php echo $_POST['topstory']; ?>"></center></p>
								<?php } ?>
								

									<form method="post" class="form-horizontal row-fluid">
										<div class="control-group">
										<label class="control-label" for="basicinput">Titulo</label>
										<div class="controls">
											<input type="text" name="title" value="<?php echo $_POST['title']?>" placeholder="News Title" class="span8">
										</div>
										</div>
										
										<div class="control-group">
											<label class="control-label" for="basicinput">Descrição</label>
											<div class="controls">
												<input type="text" name="shortstory" value="<?php echo $_POST['shortstory']?>" placeholder="News Desc" class="span8">
											</div>
										</div>
										
										<div class="control-group">
											<textarea cols="80" id="editor1" rows="10" name="longstory" class="span8"></textarea>
											<script>
												<script language="javascript" type="text/javascript">
                                                    tinyMCE.init({
                                                       mode : "textareas",
                                                       theme : "simples"
                                                        });

                                                      </script> 
											</script>
										</div>
										
										<div class="control-group">
											<label class="control-label" for="basicinput">Nick do Autor</label>
											<div class="controls">
												<input type="text" class="span8" value="<?php echo $_SESSION['user']['username']; ?>" disabled>
											</div>
										</div>
									
										<div class="control-group">
											<label class="control-label" for="basicinput">Url da Imagem de Fundo / TAMANHO : 750x242</label>
												<div class="controls">
													<input name="topstory" id="topstory" style="font-size: 14px;">
													
													</input>
													</div>
												</div>
										</div>
										
										<div class="control-group">	
											<div class="controls">	
												<input type="submit" class="btn btn-small btn-primary" name="news_create">
												<a href="cms.php" class="btn btn-primary">Voltar</a>
											</div>
										</div>
									</form>
									<?php }
									else{
										die('Go away please.');
									}
									?>
								
							</div>
						</div>
					</div>
				</div>
				</center>
				<center>
				<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Edit News</h3>
							</div>
							<div class="module-body">

								<?php
									$fetchNews = mysql_query("SELECT * FROM cms_news ORDER BY id DESC");
									while ($news = mysql_fetch_array($fetchNews))
									{
										echo '<table class="table table-striped">';
											echo '<thead>';
												echo '<tr>';
													echo '<th>ID</th>';
													echo '<th>Title</th>';
													echo '<th>Short Story</th>';
													echo '<th>Published On</th>';
													echo '<th>Author</th>';
													echo '<th>Edit</th>';
													echo '<th>Excluir</th>';
												echo '</tr>';
											echo '</thead>';
										
											echo '<tbody>';
												echo '<tr>';
													echo '<td width="5%">'. $news['id'] .'</td>';
													echo '<td width="20%">'. $news['title'] .'</td>';
													echo '<td width="25%">'. $news['shortstory'] .'</td>';
													echo '<td width="20%">' . date('l d F', $news['published']) . '</td>';
													echo '<td width="10%">'. $news['author'] .'</td>';
													echo '<td width="10%"><a href="editnews.php?url=editnews&id='.$news['id'].'" class="btn btn-small btn-primary">Edit</a></td>';
												    echo '<td width="10%"><a href="deletar.php?url=editnews&id='.$news['id'].'" class="btn btn-small btn-danger">Excluir</a></td>';
												echo '<tr/>';
											echo '</tbody>';
										echo '</table>';
														
									}
								?>						

								
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	</center>
</body>

</html>