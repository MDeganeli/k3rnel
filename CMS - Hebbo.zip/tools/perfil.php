<?php
require_once('config.php');
?>
<?php
session_start();
if(!isset($_SESSION['usuario']) || !isset($_SESSION['senha'])) {
    header("location: login.php");
    exit;
}
?>
<html>
<meta charset="utf-8">
<head>
<title>FooaPanel - Perfil</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
<!-- FIM DO CSS DO BOOTSTRAP -->
<?php  include_once("fooa/menulogado/menu.php"); ?>
<body>






</body>

</html>