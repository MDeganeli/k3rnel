<?php
require_once('config.php');
?>
<?php
session_start();
if(!isset($_SESSION['usuario']) || !isset($_SESSION['senha'])) {
    header("location: login.php");
    exit;
}
?>
<html>
<meta charset="utf-8">
<head>
<title>FooaPanel - Upload de Emblema</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
  <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
<!-- FIM DO CSS DO BOOTSTRAP -->

<body>
<center>
<div class="span9">
					<div class="content">
						<div class="module">
							<div class="module-head">
								<h3>Edit News</h3>
							</div>
							<div class="module-body">
								
								<?php
									$id = intval($_GET['id']);
									$existq = mysql_query("SELECT * FROM cms_news WHERE id = '$id'") or die(mysql_error());
									$exist = mysql_num_rows($existq);
									$news = mysql_fetch_array($existq);
									if ($exist == 0) { header('Location: ../me'); }
									if (isset($_POST['submit'])) {
									$title = mysql_real_escape_string($_POST['title']);
									$shortstory = mysql_real_escape_string($_POST['shortstory']);
									$longstory = mysql_real_escape_string($_POST['longstory']);
									$userId = $_SESSION['user']['username'];
									$time = time();
									if (empty($title) OR empty($shortstory) OR empty($longstory)) {
									echo '
									<div class="alert alert-error">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Error</strong> Please fill in all fields!
									</div>';
									} else {
										mysql_query("UPDATE cms_news SET title = '$title', shortstory = '$shortstory', longstory = '$longstory' WHERE id = '$id'") 
								or die(mysql_error());
								header("Refresh:0");
								echo '
									<div class="alert alert-success">
										<button type="button" class="close" data-dismiss="alert">×</button>
										<strong>Success!</strong> News article updated. Redirecting you back to the dashboard...
									</div>';
									header( "refresh:3;url=/ase/dash" );
									}
								}
								?>
								
								<form name="post_news" method="post" action=" "> 			
							
									<div class="control-group">
										<label class="control-label" for="inputNormal">Normal Input</label>
										<div class="controls">				
											<input type="text" name="title" id="title" value="<?php echo $news['title']; ?>" /> <br />
										</div>
									</div>				
							
									<div class="control-group">
										<label class="control-label" for="inputNormal">News Title</label>
										<div class="controls">				
											<textarea name="shortstory" id="shortstory"><?php echo $news['shortstory']; ?></textarea><br />
										</div>
									</div>
							
									<div class="control-group">
										<label class="control-label" for="inputNormal">Long Story</label>
										<div class="controls">				
											<textarea name="longstory" id="editor1"><?php echo $news['longstory']; ?></textarea>
																			<script language="javascript" type="text/javascript">
tinyMCE.init({
      mode : "textareas",
      theme : "simples"
   });

</script> 
										</div>
									</div>
									
									<div class="control-group">
										<button type="submit" class="btn btn-small btn-primary" name="submit">Edit News</button>
									</div>
								</form>
								<a href="news.php" class="btn btn-primary">Voltar</a>
								
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	</center>
</body>

</html>