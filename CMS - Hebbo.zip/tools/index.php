<?php
require_once('config.php');
?>
<?php
session_start();
if(!isset($_SESSION['usuario']) || !isset($_SESSION['senha'])) {
    header("location: login.php");
    exit;
}
?>
<html>
<meta charset="utf-8">
<head>
<title>FooaPanel - Upload de Emblema</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
<!-- FIM DO CSS DO BOOTSTRAP -->
<?php  include_once("fooa/menulogado/menu.php"); ?>
<body>


<div class="panel panel-default">
  <div class="panel-body">
    <div class="jumbotron">
  <h1>Olá, StaffZeta!</h1>
  <p>Esse painel é somente para uso da staff do HabboZeta Hotel, cuidado e não passe a senha pra ninguem !</p>
  <p>O painel se encontra <?php echo "$painels"; ?>.</p>


  <p><h2>Caracteristicas</h2></p>
  </br>
  <p><h5>Versão Atual:</h5><h4><strong><?php echo "$versao"; ?></strong></h4></p>
  </div>
  </div>
</div>



</body>

</html>