<?php
require_once('config.php');
?>
<?php
session_start();
if(!isset($_SESSION['usuario']) || !isset($_SESSION['senha'])) {
    header("location: login.php");
    exit;
}
?>
<html>
<meta charset="utf-8">
<head>
<title>FooaPanel - Upload de Emblema</title>
</head>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
<!-- FIM DO CSS DO BOOTSTRAP -->
<?php  include_once("fooa/menulogado/menu.php"); ?>
<body>
<center>
<?php

if(isset($_POST['id'])){ 
mysql_query("DELETE FROM cms_news WHERE id = '" . $_POST['id'] . "'") or die(mysql_error()); 
echo("Notícia Deletada");
}
else
{
echo("News ID cannot be found!");
}

?>
<a href="news.php" class="btn btn-success">Voltar</a>
</center>

</body>

</html>
