<?php
require_once('config.php');
?>

<html>

<head>
<title>Autenticando Usuário</title>
<script type="text/javascript">
function loginsucessfully() {
    setTimeout("window.location='index.php'", 5000);
}

function loginfailed() {
    setTimeout("window.location='login.php'", 5000);
}
</script>
<!-- CSS DO BOOTSTRAP -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/global.css" rel="stylesheet">
<!-- FIM DO CSS DO BOOTSTRAP -->
</head>

<body>
<div class="panel panel-success">
  <div class="panel-heading">
    <h3 class="panel-title">Sucesso</h3>
  </div>
  <div class="panel-body">
   <?php
$usuario=$_POST['usuario'];
$senha=$_POST['senha'];
$sql = mysql_query("SELECT * FROM usuarios WHERE usuario = '$usuario' and senha = '$senha'") or die(mysql_error());
$row  = mysql_num_rows($sql);
if($row > 0) {
    session_start();
    $_SESSION['usuario']=$_POST['usuario'];
    $_SESSION['senha']=$_POST['senha'];
    echo "<center>Você foi autenticado com sucesso! Aguarde um instante.</center>";
    echo "<script>loginsucessfully()</script>";
} else {
    echo"<center>Nome de Usuário ou Senha Incorretos! Aguarde um instante para tentar novamente.</center>";
    echo "<script>loginfailed()</script>";
}
?>
  </div>
</div>
</body>

</html>