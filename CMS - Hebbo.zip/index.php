<?php 
define('IN_INDEX', 1);

require_once 'global.php';

error_reporting(0);

$core->handleCall($engine->secure($_GET['url']));

		$template->html->get($engine->secure($_GET['url']));
	
$template->write('</html>');
$template->outputTPL();
?>
