(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.5&appId=544669852354934";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

$(document).ready(function() {
    $('a').click(function(e) {

        parts = $(this).attr('href').split('#');
        if (!!parts[1]) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: $('#' + parts[1]).offset().top
            }, 600);
        }
    });
});