$(function(){	
	/*bootstrap functions*/
	$('#tab a').click(function (e) {
	  e.preventDefault()
	  $(this).tab('show')
	})
	$('[data-toggle="tooltip"]').tooltip()
	$('img.lazy, div.lazy').lazyload({ effect : "fadeIn" });
	$('[data-toggle="popover"]').popover();
	document.cookie = "hebbocookie=supported";
    var cookiesEnabled = document.cookie.indexOf("hebbocookie") != -1;
    if (cookiesEnabled) {
        var date = new Date();
        date.setTime(date.getTime()-24*60*60*1000);
        document.cookie="hebbocookie=supported; expires="+date.toGMTString();
		
		var privacyCookie = document.cookie.indexOf("privacycookie") != -1;
		
		if(!privacyCookie){
			$('#privacy_cookies').fadeIn();
			$(document).on('click', '#acceptPrivacyCookie', function(){
				
				document.cookie = "privacycookie=accepted;path=/;max-age=" + 60 * 60 * 24 * 1000;
				
				$('#privacy_cookies').fadeOut();
			});
		}
    } else {
		$('#no_cookies').fadeIn();
    }
});